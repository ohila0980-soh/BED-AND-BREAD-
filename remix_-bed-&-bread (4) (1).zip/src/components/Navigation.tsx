import React from 'react';
import { NavLink, Link, useNavigate } from 'react-router-dom';
import { Home, Menu, X, User, LogOut, Award, MapPin, Gift, LayoutDashboard, UtensilsCrossed, Phone, Soup, Mail, ChevronDown, Package } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Logo } from './Logo';
import { useApp } from '../AppContext';
import { cn } from '../lib/utils';

export const Navbar = () => {
  const [isOpen, setIsOpen] = React.useState(false);
  const [showFindMenu, setShowFindMenu] = React.useState(false);
  const { user, logout, loading } = useApp();
  const navigate = useNavigate();

  const navLinks = [
    { to: '/', label: 'Home', icon: Home },
    { to: '/find-shelter', label: 'Find Shelter', icon: MapPin },
    { 
      label: 'Find Help', 
      icon: ChevronDown,
      isDropdown: true,
      subLinks: [
        { to: '/available-food', label: 'Find Food', icon: Soup },
        { to: '/available-donations', label: 'Find Items', icon: Package },
      ]
    },
    { to: '/donate', label: 'Donate', icon: Gift },
    { to: '/foodshare', label: 'FoodShare', icon: UtensilsCrossed },
    { to: '/dashboard', label: 'Dashboard', icon: LayoutDashboard },
  ];

  if (loading) return null;

  return (
    <nav className="bg-white border-b border-slate-200 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex items-center">
            <Link to="/" className="flex items-center space-x-2">
              <div className="bg-white p-1 rounded-xl shadow-sm border border-orange-50 flex items-center justify-center">
                <Logo size={28} />
              </div>
              <span className="text-2xl font-black text-earth tracking-tighter">Bed & Bread</span>
            </Link>
          </div>

          {/* Desktop Nav */}
          <div className="hidden md:flex items-center space-x-1">
            {navLinks.map((link) => (
              link.isDropdown ? (
                <div 
                  key={link.label}
                  className="relative"
                  onMouseEnter={() => setShowFindMenu(true)}
                  onMouseLeave={() => setShowFindMenu(false)}
                >
                  <button
                    className={cn(
                      "px-4 py-2 rounded-md text-xs font-bold uppercase tracking-widest transition-colors flex items-center space-x-1.5 text-slate-500 hover:text-primary"
                    )}
                  >
                    <span>{link.label}</span>
                    <ChevronDown className={cn("h-3 w-3 transition-transform", showFindMenu && "rotate-180")} />
                  </button>
                  
                  <AnimatePresence>
                    {showFindMenu && (
                      <motion.div
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: 10 }}
                        className="absolute left-0 mt-1 w-48 bg-white border border-slate-100 rounded-2xl shadow-xl p-2 z-50 overflow-hidden"
                      >
                        {link.subLinks?.map(sub => (
                          <Link
                            key={sub.to}
                            to={sub.to}
                            className="flex items-center gap-3 px-4 py-3 text-xs font-bold text-slate-600 hover:text-primary hover:bg-orange-50 rounded-xl transition-all"
                          >
                            <sub.icon className="h-4 w-4" />
                            {sub.label}
                          </Link>
                        ))}
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              ) : (
                <NavLink
                  key={link.to}
                  to={link.to!}
                  className={({ isActive }) =>
                    cn(
                      "px-4 py-2 rounded-md text-xs font-bold uppercase tracking-widest transition-colors flex items-center space-x-1.5",
                      isActive ? "text-primary" : "text-slate-500 hover:text-primary"
                    )
                  }
                >
                  <span>{link.label}</span>
                </NavLink>
              )
            ))}
            
            {user ? (
              <div className="flex items-center ml-4 pl-4 border-l border-slate-200">
                <div className="text-right mr-3">
                  <div className="text-[10px] font-black text-slate-400 uppercase tracking-widest leading-none">Logged in as</div>
                  <div className="text-sm font-black text-clay-deep">{user.fullName}</div>
                  <div className="text-xs font-bold text-sage">{user.points} XP</div>
                </div>
                <button
                  onClick={() => { logout(); navigate('/'); }}
                  className="w-10 h-10 rounded-full bg-slate-100 flex items-center justify-center font-bold text-slate-600 hover:bg-red-50 hover:text-red-600 transition-all border border-slate-200"
                  title="Logout"
                >
                  <LogOut className="h-5 w-5" />
                </button>
              </div>
            ) : (
              <Link
                to="/auth"
                className="ml-4 inline-flex items-center justify-center px-4 py-2 border border-transparent text-sm font-medium rounded-lg text-white bg-primary hover:bg-clay-deep shadow-sm transition-all"
              >
                Sign In
              </Link>
            )}
          </div>

          {/* Mobile menu button */}
          <div className="md:hidden flex items-center">
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="p-2 rounded-md text-slate-500 hover:text-primary"
            >
              {isOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Nav */}
      {isOpen && (
        <div className="md:hidden bg-white border-t border-slate-100">
          <div className="px-2 pt-2 pb-3 space-y-1">
            {navLinks.map((link) => (
              link.isDropdown ? (
                <div key={link.label} className="space-y-1">
                  <div className="px-3 py-2 text-xs font-black uppercase tracking-widest text-slate-400">
                    {link.label}
                  </div>
                  {link.subLinks?.map(sub => (
                    <NavLink
                      key={sub.to}
                      to={sub.to}
                      onClick={() => setIsOpen(false)}
                      className={({ isActive }) =>
                        cn(
                          "block px-3 py-2 rounded-md text-base font-medium transition-colors flex items-center space-x-3",
                          isActive ? "text-primary bg-orange-50" : "text-slate-600 hover:text-primary hover:bg-orange-50"
                        )
                      }
                    >
                      <sub.icon className="h-5 w-5" />
                      <span>{sub.label}</span>
                    </NavLink>
                  ))}
                </div>
              ) : (
                <NavLink
                  key={link.to}
                  to={link.to!}
                  onClick={() => setIsOpen(false)}
                  className={({ isActive }) =>
                    cn(
                      "block px-3 py-2 rounded-md text-base font-medium transition-colors flex items-center space-x-3",
                      isActive ? "text-primary bg-orange-50" : "text-slate-600 hover:text-primary hover:bg-orange-50"
                    )
                  }
                >
                  <link.icon className="h-5 w-5" />
                  <span>{link.label}</span>
                </NavLink>
              )
            ))}
            {!user && (
              <Link
                to="/auth"
                onClick={() => setIsOpen(false)}
                className="block w-full text-center px-3 py-3 mt-4 text-base font-medium text-white bg-primary rounded-lg"
              >
                Sign In
              </Link>
            )}
            {user && (
              <button
                onClick={() => { logout(); setIsOpen(false); navigate('/'); }}
                className="block w-full text-left px-3 py-2 text-base font-medium text-red-600 hover:bg-red-50 rounded-md"
              >
                Logout
              </button>
            )}
          </div>
        </div>
      )}
    </nav>
  );
};

export const Footer = () => (
  <footer className="bg-white border-t border-slate-200 py-12">
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
        <div className="col-span-1 md:col-span-2">
          <Link to="/" className="flex items-center space-x-2 mb-4">
            <Logo size={24} />
            <span className="text-xl font-bold tracking-tight text-clay-deep">Bed & Bread</span>
          </Link>
          <p className="text-slate-500 max-w-sm">
            Empowering the community to care for the vulnerable. Our mission is to ensure every child and senior citizen has a safe place to call home.
          </p>
        </div>
        <div>
          <h4 className="text-sm font-black text-slate-900 uppercase tracking-widest mb-4">Quick Links</h4>
          <ul className="space-y-2">
            <li><Link to="/find-shelter" className="text-slate-500 hover:text-primary text-sm font-medium">Report & Help</Link></li>
            <li><Link to="/available-food" className="text-slate-500 hover:text-primary text-sm font-medium">Find Available Food</Link></li>
            <li><Link to="/donate" className="text-slate-500 hover:text-primary text-sm font-medium">Donate Items</Link></li>
            <li><Link to="/foodshare" className="text-slate-500 hover:text-primary text-sm font-medium">Food Donation</Link></li>
            <li><Link to="/dashboard" className="text-slate-500 hover:text-primary text-sm font-medium">Your Dashboard</Link></li>
          </ul>
        </div>
        <div>
          <h4 className="text-sm font-black text-slate-900 uppercase tracking-widest mb-4">Contact Details</h4>
          <ul className="space-y-3 text-sm text-slate-500">
            <li className="flex items-center gap-2 font-medium">
              <Phone className="h-4 w-4 text-primary" /> +91 80 1234 5678
            </li>
            <li className="flex items-center gap-2 font-medium">
              <Mail className="h-4 w-4 text-primary" />
              support@bedandbread.org
            </li>
            <li className="flex items-center gap-2 font-medium">
              <MapPin className="h-4 w-4 text-primary" /> Tech Park, Indiranagar, Bengaluru
            </li>
            <li className="flex items-center gap-2 pt-2">
               <span className="text-[10px] bg-sand px-2 py-1 rounded text-primary font-bold uppercase tracking-widest">Available 24/7</span>
               <span className="text-[10px] ml-2 text-slate-400 font-bold uppercase tracking-widest">Resp: 4-6 hrs</span>
            </li>
            <li className="flex gap-3 pt-4">
              <div className="p-2 bg-sand rounded-lg border border-orange-50 hover:text-primary transition-colors cursor-pointer">
                <svg className="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M22 4s-.7 2.1-2 3.4c1.6 10-9.4 17.3-18 11.6 2.2.1 4.4-.6 6-2C3 15.5.5 9.6 3 5c2.2 2.6 5.6 4.1 9 4-.9-4.2 4-6.6 7-3.8 1.1 0 3-1.2 3-1.2z"/></svg>
              </div>
              <div className="p-2 bg-sand rounded-lg border border-orange-50 hover:text-primary transition-colors cursor-pointer">
                <svg className="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect x="2" y="2" width="20" height="20" rx="5" ry="5"/><path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"/><line x1="17.5" y1="6.5" x2="17.51" y2="6.5"/></svg>
              </div>
              <div className="p-2 bg-sand rounded-lg border border-orange-50 hover:text-primary transition-colors cursor-pointer">
                <svg className="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z"/><rect x="2" y="9" width="4" height="12"/><circle cx="4" cy="4" r="2"/></svg>
              </div>
            </li>
          </ul>
        </div>
      </div>
      <div className="mt-12 pt-8 border-t border-slate-100 flex flex-col md:flex-row justify-between items-center">
        <p className="text-sm text-slate-400">© 2026 Bed & Bread. All rights reserved.</p>
        <div className="flex space-x-6 mt-4 md:mt-0">
          <span className="text-sm text-slate-400 hover:text-primary cursor-pointer">Privacy Policy</span>
          <span className="text-sm text-slate-400 hover:text-primary cursor-pointer">Terms of Service</span>
        </div>
      </div>
    </div>
  </footer>
);
