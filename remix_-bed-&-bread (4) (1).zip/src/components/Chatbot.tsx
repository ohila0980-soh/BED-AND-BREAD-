import React, { useState, useRef, useEffect } from 'react';
import { MessageCircle, X, Send, Bot, User, Loader2, Sparkles, AlertCircle } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { chatWithGemini } from '../services/geminiService';
import { cn } from '../lib/utils';

interface Message {
  id: string;
  role: 'user' | 'model';
  text: string;
}

export const Chatbot = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    { id: '1', role: 'model', text: "Namaste! I'm your Bed and Bread assistant. How can I help you today?" }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const chatEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isLoading]);

  const handleSend = async (e?: React.FormEvent) => {
    e?.preventDefault();
    if (!input.trim() || isLoading) return;

    const userMessage: Message = { id: Date.now().toString(), role: 'user', text: input };
    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsLoading(true);

    try {
      const history = messages.map(m => ({
        role: m.role,
        parts: [{ text: m.text }]
      }));

      const response = await chatWithGemini(input, history);
      
      // Split response into chunks to avoid "wall of text"
      const chunks = response.split(/\n\n+/).filter(c => c.trim().length > 0);
      
      for (let i = 0; i < chunks.length; i++) {
        // Add a slight delay for multiple chunks to feel natural
        if (i > 0) {
          setIsLoading(true);
          await new Promise(resolve => setTimeout(resolve, 800 + Math.random() * 500));
        }
        
        const aiMessage: Message = { id: (Date.now() + i + 1).toString(), role: 'model', text: chunks[i] };
        setMessages(prev => [...prev, aiMessage]);
        setIsLoading(false);
      }
    } catch (error) {
      console.error(error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed bottom-6 right-6 z-[9999]">
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, scale: 0.8, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.8, y: 20 }}
            className="mb-4 w-[350px] md:w-[400px] h-[500px] md:h-[600px] bg-white rounded-[2.5rem] shadow-2xl border border-orange-100 flex flex-col overflow-hidden"
          >
            {/* Header */}
            <div className="bg-earth p-6 flex justify-between items-center text-white">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-primary rounded-full flex items-center justify-center">
                  <Bot className="h-5 w-5" />
                </div>
                <div>
                  <h3 className="font-black text-sm uppercase tracking-widest">Helper AI</h3>
                  <div className="flex items-center gap-1">
                    <div className="w-1.5 h-1.5 bg-green-500 rounded-full"></div>
                    <span className="text-[10px] font-bold text-white/60">Active now</span>
                  </div>
                </div>
              </div>
              <button 
                onClick={() => setIsOpen(false)}
                className="p-2 hover:bg-white/10 rounded-full transition-colors"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            {/* Messages */}
            <div className="flex-grow overflow-y-auto p-6 space-y-4 scrollbar-hide bg-sand/30">
              {messages.map((m) => (
                <div 
                  key={m.id}
                  className={cn(
                    "flex flex-col max-w-[85%]",
                    m.role === 'user' ? "ml-auto items-end" : "mr-auto items-start"
                  )}
                >
                  <div className={cn(
                    "px-4 py-3 rounded-2xl text-sm font-medium",
                    m.role === 'user' 
                      ? "bg-primary text-white rounded-br-none" 
                      : "bg-white text-earth border border-orange-100 rounded-bl-none shadow-sm"
                  )}>
                    {m.text}
                  </div>
                  <span className="text-[9px] font-bold text-slate-400 mt-1 px-1">
                    {m.role === 'user' ? 'You' : 'Assistant'}
                  </span>
                </div>
              ))}
              {isLoading && (
                <div className="flex gap-2 items-center text-slate-400">
                  <div className="bg-white border border-orange-100 px-4 py-3 rounded-2xl rounded-bl-none shadow-sm">
                    <Loader2 className="h-4 w-4 animate-spin text-primary" />
                  </div>
                </div>
              )}
              <div ref={chatEndRef} />
            </div>

            {/* Suggestions */}
            {!isLoading && messages.length < 3 && (
              <div className="p-4 flex gap-2 overflow-x-auto scrollbar-hide">
                {['How to donate?', 'Find shelters', 'Report someone'].map((s) => (
                  <button 
                    key={s}
                    onClick={() => { setInput(s); handleSend(); }}
                    className="shrink-0 px-4 py-2 bg-white border border-orange-100 rounded-full text-[10px] font-bold text-primary hover:bg-primary hover:text-white transition-all transition-colors"
                  >
                    {s}
                  </button>
                ))}
              </div>
            )}

            {/* Input */}
            <form onSubmit={handleSend} className="p-6 bg-white border-t border-orange-50">
              <div className="relative">
                <input 
                  className="w-full pl-6 pr-14 py-4 bg-sand rounded-2xl outline-none font-bold text-earth border border-transparent focus:border-primary transition-all text-sm"
                  placeholder="Type your message..."
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                />
                <button 
                  type="submit"
                  disabled={!input.trim() || isLoading}
                  className="absolute right-2 top-1/2 -translate-y-1/2 p-2 bg-primary text-white rounded-xl hover:bg-clay-deep transition-all disabled:opacity-50"
                >
                  <Send className="h-4 w-4" />
                </button>
              </div>
              <p className="text-[8px] text-center text-slate-400 mt-4 font-bold uppercase tracking-widest flex items-center justify-center gap-1">
                <Sparkles className="h-3 w-3" /> AI generated for community use
              </p>
            </form>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Toggle Button */}
      <motion.button
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.9 }}
        onClick={() => setIsOpen(!isOpen)}
        className={cn(
          "w-16 h-16 rounded-full shadow-2xl flex items-center justify-center transition-all relative overflow-hidden",
          isOpen ? "bg-earth rotate-90" : "bg-primary"
        )}
      >
        <div className="absolute inset-0 bg-gradient-to-tr from-black/20 to-transparent opacity-0 hover:opacity-100 transition-opacity" />
        {isOpen ? (
          <X className="h-6 w-6 text-white" />
        ) : (
          <div className="relative">
            <MessageCircle className="h-8 w-8 text-white" />
            <div className="absolute -top-1 -right-1 w-3 h-3 bg-white rounded-full flex items-center justify-center">
              <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
            </div>
          </div>
        )}
      </motion.button>
    </div>
  );
};
