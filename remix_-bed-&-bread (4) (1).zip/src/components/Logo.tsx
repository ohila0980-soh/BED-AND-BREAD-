import React from 'react';

interface LogoProps {
  className?: string;
  size?: number;
}

export const Logo: React.FC<LogoProps> = ({ className = '', size = 32 }) => {
  return (
    <svg 
      width={size} 
      height={size} 
      viewBox="0 0 100 100" 
      fill="none" 
      xmlns="http://www.w3.org/2000/svg"
      className={className}
    >
      {/* Roof Shape */}
      <path 
        d="M15 45L50 15L85 45" 
        stroke="#C05621" 
        strokeWidth="12" 
        strokeLinecap="round" 
        strokeLinejoin="round" 
      />
      
      {/* Bread Loaf */}
      <path 
        d="M25 60C25 45 75 45 75 60C75 75 25 75 25 60Z" 
        fill="#F6AD55"
      />
      
      {/* Bread Details (Slant lines) */}
      <path d="M38 55L42 50" stroke="#C05621" strokeWidth="2" strokeLinecap="round" opacity="0.4" />
      <path d="M48 55L52 50" stroke="#C05621" strokeWidth="2" strokeLinecap="round" opacity="0.4" />
      <path d="M58 55L62 50" stroke="#C05621" strokeWidth="2" strokeLinecap="round" opacity="0.4" />
    </svg>
  );
};
