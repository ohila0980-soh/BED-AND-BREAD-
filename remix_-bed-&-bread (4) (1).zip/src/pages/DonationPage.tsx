import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Gift, Package, Utensils, Book, Pill, CreditCard, MapPin, Clock, ArrowRight, Star, Heart } from 'lucide-react';
import { useApp } from '../AppContext';
import { POINT_VALUES } from '../constants';
import { motion } from 'motion/react';
import { cn } from '../lib/utils';

type DonationType = 'Clothes' | 'Food' | 'Books' | 'Medicines' | 'Funds';

export const DonationPage = () => {
  const [activeType, setActiveType] = useState<DonationType>('Funds');
  const { addDonation, user } = useApp();
  const navigate = useNavigate();
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleDonate = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    
    if (!user) {
      navigate('/auth', { state: { from: '/donate' } });
      return;
    }

    setSubmitting(true);
    try {
      const formData = new FormData(e.target as HTMLFormElement);
      const contact = formData.get('whatsappNumber') as string;
      const location = formData.get('pickup') as string;
      
      let points = POINT_VALUES.DONATE_FUNDS;
      let details = "";

      if (activeType === 'Clothes') {
        points = POINT_VALUES.DONATE_CLOTHES;
        details = `${formData.get('quantity')} items of ${formData.get('clothesType')}`;
      } else if (activeType === 'Food') {
        points = POINT_VALUES.DONATE_FOOD;
        details = `${formData.get('foodType')} (${formData.get('quantity')})`;
      } else if (activeType === 'Books') {
        points = POINT_VALUES.DONATE_FUNDS;
        details = `${formData.get('quantity')} books (${formData.get('category')})`;
      } else if (activeType === 'Medicines') {
        points = POINT_VALUES.DONATE_FUNDS;
        details = `${formData.get('medicineNames')}`;
      } else {
        const amount = formData.get('amount') as string;
        if (!amount || parseInt(amount) <= 0) {
          throw new Error('Please enter a valid donation amount.');
        }
        details = `₹${amount}`;
      }

      const donationData: any = {
        type: activeType,
        details,
        pointsEarned: points,
        whatsappNumber: contact || '',
        location: location || ''
      };
      
      if (activeType === 'Funds') {
        donationData.amount = formData.get('amount') as string;
      }

      await addDonation(donationData);

      navigate('/donation-success', { state: { pointsEarned: points } });
    } catch (err: any) {
      console.error("Donation Error:", err);
      setError(err.message || "Something went wrong with your donation. Please try again.");
    } finally {
      setSubmitting(false);
    }
  };

  const donationModes = [
    { id: 'Funds' as DonationType, icon: CreditCard, label: 'Funds' },
    { id: 'Clothes' as DonationType, icon: Package, label: 'Clothes' },
    { id: 'Food' as DonationType, icon: Utensils, label: 'Food' },
    { id: 'Books' as DonationType, icon: Book, label: 'Books' },
    { id: 'Medicines' as DonationType, icon: Pill, label: 'Medicines' },
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 py-12">
      <header className="mb-12 text-center max-w-3xl mx-auto">
        <h1 className="text-4xl font-bold text-clay-deep mb-4 tracking-tight">Make a Donation</h1>
        <p className="text-slate-600">
          Your contribution, no matter how small, brings hope and comfort to someone's life. Choose a donation type below to get started.
        </p>
      </header>

      <div className="grid lg:grid-cols-12 gap-12">
        {/* Type Selection */}
        <div className="lg:col-span-4 space-y-4">
          {donationModes.map((mode) => (
            <button
              key={mode.id}
              onClick={() => setActiveType(mode.id)}
              className={cn(
                "w-full flex items-center gap-4 p-6 rounded-[2rem] border-2 transition-all text-left",
                activeType === mode.id 
                  ? "bg-primary border-primary text-white shadow-lg shadow-orange-900/10" 
                  : "bg-white border-orange-50 text-slate-700 hover:border-primary"
              )}
            >
              <div className={cn("p-3 rounded-xl", activeType === mode.id ? "bg-white/20" : "bg-slate-50")}>
                <mode.icon className="h-6 w-6" />
              </div>
              <div>
                <div className="font-bold text-earth">{mode.label}</div>
                <div className={cn("text-sm", activeType === mode.id ? "text-white/80" : "text-slate-500")}>
                  Donate {mode.label.toLowerCase()} to shelters
                </div>
              </div>
            </button>
          ))}

          <div className="bg-orange-50 p-6 rounded-[2rem] border border-orange-100 mt-8">
            <div className="flex gap-4">
              <Star className="h-6 w-6 text-clay-light fill-clay-light flex-none" />
              <div>
                <h4 className="font-bold text-clay-deep mb-1">Did you know?</h4>
                <p className="text-sm text-clay-light leading-relaxed">
                  Every donation earns you points which you can redeem for verified community certificates and local business coupons!
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Dynamic Form */}
        <motion.div 
          key={activeType}
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          className="lg:col-span-8 bg-white p-8 md:p-12 rounded-[2.5rem] shadow-xl border border-orange-50"
        >
          <div className="flex items-center gap-3 mb-8">
            <Gift className="h-8 w-8 text-primary" />
            <h2 className="text-2xl font-bold text-clay-deep">{activeType} Donation Details</h2>
          </div>

          <form onSubmit={handleDonate} className="space-y-6">
            {activeType === 'Clothes' && (
              <div className="grid md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-sm font-bold text-earth">Number of Clothes</label>
                  <input required name="quantity" type="number" className="w-full px-4 py-3 bg-sand border border-orange-100 rounded-2xl focus:ring-2 focus:ring-primary outline-none" placeholder="e.g. 5" />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-bold text-earth">Type of Clothes</label>
                  <select name="clothesType" className="w-full px-4 py-3 bg-sand border border-orange-100 rounded-2xl focus:ring-2 focus:ring-primary outline-none">
                    <option>Summer Wear</option>
                    <option>Winter Wear</option>
                    <option>Infant Clothing</option>
                    <option>Formal/Uniforms</option>
                  </select>
                </div>
                <div className="md:col-span-2 space-y-2">
                  <label className="text-sm font-bold text-earth">WhatsApp Number</label>
                  <input required name="whatsappNumber" className="w-full px-4 py-3 bg-sand border border-orange-100 rounded-2xl" placeholder="e.g. 9876543210" />
                </div>
                <div className="md:col-span-2 space-y-2">
                  <label className="text-sm font-bold text-earth">Pickup Location</label>
                  <div className="relative">
                    <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-slate-400" />
                    <input required name="pickup" className="w-full pl-11 pr-4 py-3 bg-sand border border-orange-100 rounded-2xl outline-none" placeholder="Complete address for pickup" />
                  </div>
                </div>
              </div>
            )}

            {activeType === 'Food' && (
              <div className="grid md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-sm font-bold text-earth">Food Type</label>
                  <input required name="foodType" className="w-full px-4 py-3 bg-sand border border-orange-100 rounded-2xl" placeholder="e.g. Dry Groceries, Cooked Meal" />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-bold text-earth">Quantity</label>
                  <input required name="quantity" className="w-full px-4 py-3 bg-sand border border-orange-100 rounded-2xl" placeholder="e.g. 5kg, 10 meals" />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-bold text-earth">Pickup Time</label>
                  <div className="relative">
                    <Clock className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-slate-400" />
                    <input required name="time" type="time" className="w-full pl-11 pr-4 py-3 bg-sand border border-orange-100 rounded-2xl" />
                  </div>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-bold text-earth">WhatsApp Number</label>
                  <input required name="whatsappNumber" className="w-full px-4 py-3 bg-sand border border-orange-100 rounded-2xl" placeholder="e.g. 9876543210" />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-bold text-earth">Location</label>
                  <input required name="pickup" className="w-full px-4 py-3 bg-sand border border-orange-100 rounded-2xl" placeholder="Pickup address" />
                </div>
              </div>
            )}

            {activeType === 'Books' && (
              <div className="grid md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-sm font-bold text-earth">Number of Books</label>
                  <input required name="quantity" type="number" className="w-full px-4 py-3 bg-sand border border-orange-100 rounded-2xl" />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-bold text-earth">Category</label>
                  <select name="category" className="w-full px-4 py-3 bg-sand border border-orange-100 rounded-2xl">
                    <option>School Textbooks</option>
                    <option>Story Books</option>
                    <option>General Knowledge</option>
                    <option>Skill Development</option>
                  </select>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-bold text-earth">WhatsApp Number</label>
                  <input required name="whatsappNumber" className="w-full px-4 py-3 bg-sand border border-orange-100 rounded-2xl" placeholder="e.g. 9876543210" />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-bold text-earth">Pickup Location</label>
                  <input required name="pickup" className="w-full px-4 py-3 bg-sand border border-orange-100 rounded-2xl" placeholder="Complete address for pickup" />
                </div>
              </div>
            )}

            {activeType === 'Medicines' && (
              <div className="space-y-4">
                <div className="space-y-2">
                  <label className="text-sm font-bold text-earth">Medicine Names & Quantities</label>
                  <textarea required name="medicineNames" className="w-full px-4 py-3 bg-sand border border-orange-100 rounded-2xl min-h-[100px]" placeholder="List names and quantities..." />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-bold text-earth">WhatsApp Number</label>
                  <input required name="whatsappNumber" className="w-full px-4 py-3 bg-sand border border-orange-100 rounded-2xl" placeholder="e.g. 9876543210" />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-bold text-earth">Pickup Location</label>
                  <input required name="pickup" className="w-full px-4 py-3 bg-sand border border-orange-100 rounded-2xl" placeholder="Complete address for pickup" />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-bold text-earth">Expiry Date (Latest)</label>
                  <input required name="expiry" type="date" className="w-full px-4 py-3 bg-sand border border-orange-100 rounded-2xl" />
                </div>
              </div>
            )}

            {activeType === 'Funds' && (
              <div className="space-y-6">
                <div className="space-y-2">
                  <label className="text-sm font-bold text-earth">Donation Amount (INR)</label>
                  <div className="relative">
                    <span className="absolute left-4 top-1/2 -translate-y-1/2 font-bold text-slate-400">₹</span>
                    <input required name="amount" type="number" className="w-full pl-10 pr-4 py-4 bg-sand border-2 border-orange-100 rounded-2xl text-2xl font-bold focus:border-primary outline-none transition-all text-clay-deep" placeholder="500" />
                  </div>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-bold text-earth">Payment Method</label>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    {['UPI', 'Card', 'Net Banking', 'Cash'].map(p => (
                      <div key={p} className="cursor-pointer border-2 border-orange-50 rounded-2xl p-3 text-center hover:border-primary transition-all bg-sand">
                        <span className="text-xs font-bold text-earth">{p}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {error && (
              <div className="p-4 bg-red-50 text-red-600 text-sm font-bold rounded-2xl border border-red-100 mb-6">
                {error}
              </div>
            )}

            <button
              type="submit"
              disabled={submitting}
              className="w-full py-5 bg-primary hover:bg-clay-deep text-white font-bold rounded-2xl shadow-xl hover:shadow-orange-900/10 transition-all flex items-center justify-center gap-3 group mt-10 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {submitting ? 'Processing...' : 'Ready to Help'}
              {!submitting && <Heart className="h-6 w-6 group-hover:scale-110 transition-transform" />}
            </button>
          </form>
        </motion.div>
      </div>
    </div>
  );
};
