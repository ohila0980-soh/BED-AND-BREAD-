import React from 'react';
import { motion } from 'motion/react';
import { Home, MapPin, Gift, UtensilsCrossed, Award, LayoutDashboard, Phone, Users, Shield, ArrowRight, HandHeart } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import { cn } from '../lib/utils';

export const LandingPage = () => {
  return (
    <div className="space-y-20 pb-20">
      {/* Hero Section */}
      <section className="relative h-[80vh] flex items-center justify-center overflow-hidden bg-slate-900">
        <div className="absolute inset-0 opacity-40">
          <img 
            src="https://images.unsplash.com/photo-1488521787991-ed7bbaae773c?q=80&w=2070&auto=format&fit=crop" 
            alt="Community helping" 
            className="w-full h-full object-cover"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-linear-to-t from-slate-900 to-transparent"></div>
        </div>
        
        <div className="relative max-w-7xl mx-auto px-4 text-center z-10">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <span className="inline-block px-4 py-1.5 mb-6 text-xs font-black tracking-[0.2em] text-clay-light uppercase bg-clay-light/10 rounded-full border border-clay-light/20">
              Community for Change
            </span>
            <h1 className="text-6xl md:text-8xl font-black text-white tracking-tighter mb-8 leading-[0.9]">
              HELP SOMEONE <br />
              <span className="text-clay-light">FIND A HOME.</span>
            </h1>
            <p className="text-xl text-slate-300 max-w-md mx-auto mb-10 leading-relaxed font-medium">
              Report a person in need to instantly match them with Bengaluru's nearest verified shelters.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <Link 
                to="/find-shelter" 
                className="w-full sm:w-auto px-10 py-5 bg-primary hover:bg-clay-deep text-white font-black rounded-[2rem] shadow-xl hover:shadow-orange-900/20 transition-all flex items-center justify-center gap-3 uppercase tracking-wider text-sm"
              >
                Report Person <span className="bg-white/20 px-2 py-0.5 rounded text-[10px] tracking-normal font-bold">+50 XP</span>
              </Link>
              <Link 
                to="/donate" 
                className="w-full sm:w-auto px-10 py-5 bg-white/10 hover:bg-white/20 text-white font-black rounded-[2rem] backdrop-blur-sm border border-white/20 transition-all flex items-center justify-center gap-2 uppercase tracking-wider text-sm"
              >
                Donate Items
              </Link>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="max-w-7xl mx-auto px-4">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
          {[
            { label: 'Children Helped', value: '450+', icon: Users, color: 'text-primary' },
            { label: 'Shelters Linked', value: '120+', icon: MapPin, color: 'text-sage' },
            { label: 'Food Shared', value: '1.2 Tons', icon: UtensilsCrossed, color: 'text-clay-light' },
            { label: 'Active Donors', value: '800+', icon: HandHeart, color: 'text-clay-deep' },
          ].map((stat, i) => (
            <motion.div 
              key={i}
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              className="bg-white p-8 rounded-[2.5rem] border border-orange-50 shadow-sm hover:shadow-md transition-shadow text-center"
            >
              <stat.icon className={cn("h-8 w-8 mx-auto mb-4", stat.color)} />
              <div className="text-3xl font-bold text-slate-900 mb-1">{stat.value}</div>
              <div className="text-sm text-slate-500 font-medium">{stat.label}</div>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Helping Hands Section */}
      <section className="max-w-7xl mx-auto px-4 py-10">
        <div className="grid lg:grid-cols-2 gap-12 items-center mb-16">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
          >
            <h2 className="text-4xl md:text-6xl font-black text-earth tracking-tighter mb-6">Helping <span className="text-primary">Hands</span></h2>
            <p className="text-slate-500 max-w-xl font-medium text-lg leading-relaxed">
              Small actions lead to big changes. Join the community and earn points for every act of kindness. Our platform makes it easy to report needs and share resources.
            </p>
          </motion.div>
          <motion.div
             initial={{ opacity: 0, scale: 0.95 }}
             whileInView={{ opacity: 1, scale: 1 }}
             viewport={{ once: true }}
             className="relative aspect-video rounded-[3rem] overflow-hidden border-8 border-white shadow-2xl"
          >
            <img 
              src="https://images.unsplash.com/photo-1488521787991-ed7bbaae773c?q=80&w=2070&auto=format&fit=crop" 
              alt="Children sharing food"
              className="w-full h-full object-cover"
              referrerPolicy="no-referrer"
            />
            <div className="absolute inset-0 bg-linear-to-t from-earth/40 to-transparent"></div>
          </motion.div>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {[
            { 
              title: "Report & Connect", 
              desc: "Spot someone in need? Report their location and our system matches them with the closest verified shelter.",
              icon: MapPin,
              points: "+50 XP",
              link: "/find-shelter",
              color: "bg-orange-50 text-primary"
            },
            { 
              title: "Share a Meal", 
              desc: "Have leftover food from an event or restaurant? List it on FoodShare to feed those in local shelters.",
              icon: UtensilsCrossed,
              points: "+20 XP",
              link: "/foodshare",
              color: "bg-sage/10 text-sage"
            },
            { 
              title: "Donate Essentials", 
              desc: "From clothes to funds, your donations go directly to orphanages and old-age homes in our network.",
              icon: Gift,
              points: "+15 XP",
              link: "/donate",
              color: "bg-clay-light/10 text-clay-deep"
            }
          ].map((item, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="bg-white p-8 rounded-[3rem] border border-orange-50 shadow-lg hover:shadow-xl transition-all group flex flex-col h-full"
            >
              <div className={cn("w-16 h-16 rounded-[1.5rem] flex items-center justify-center mb-6 transition-transform group-hover:scale-110", item.color)}>
                <item.icon className="h-8 w-8" />
              </div>
              <div className="flex-grow">
                <h3 className="text-2xl font-bold text-earth mb-3">{item.title}</h3>
                <p className="text-slate-500 mb-6 leading-relaxed text-sm">
                  {item.desc}
                </p>
              </div>
              <Link 
                to={item.link}
                className="flex items-center justify-between mt-auto pt-6 border-t border-slate-50 group/link"
              >
                <div className="flex items-center gap-2 font-black text-xs uppercase tracking-widest text-primary">
                  Start Helping <ArrowRight className="h-4 w-4 group-hover/link:translate-x-1 transition-transform" />
                </div>
                <span className="text-[10px] bg-slate-900 text-white px-2 py-1 rounded-lg font-bold">
                  {item.points}
                </span>
              </Link>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Intro Section */}
      <section className="max-w-7xl mx-auto px-4 py-10">
        <div className="bg-white rounded-[3rem] overflow-hidden border border-orange-50 shadow-xl flex flex-col lg:flex-row">
          <div className="lg:w-1/2 p-10 lg:p-20 flex flex-col justify-center">
            <h2 className="text-3xl font-bold text-clay-deep mb-6">Our Impact Strategy</h2>
            <p className="text-slate-600 mb-8 leading-relaxed">
              Bed & Bread is more than just a directory. We build a bridge between those who need help and those who want to provide it. By gamifying social impact, we encourage consistent community contribution.
            </p>
            <div className="space-y-4">
              {[
                { title: 'Verified Shelters', desc: 'Every listed shelter is audited for safety and hygiene.' },
                { title: 'FoodShare Network', desc: 'Reducing food waste by connecting event leftover to shelters.' },
                { title: 'Job Placement', desc: 'Providing meaningful work opportunities within the care system.' },
              ].map((item, i) => (
                <div key={i} className="flex gap-4">
                  <div className="flex-none bg-orange-50 p-2 rounded-[1rem] h-fit">
                    <Shield className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <h4 className="font-bold text-earth">{item.title}</h4>
                    <p className="text-sm text-slate-500">{item.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
          <div className="lg:w-1/2 bg-orange-50/10 p-8 flex items-center justify-center min-h-[500px]">
             <div className="grid grid-cols-2 gap-6 w-full max-w-md relative">
               <motion.div 
                 initial={{ opacity: 0, x: -20 }}
                 whileInView={{ opacity: 1, x: 0 }}
                 viewport={{ once: true }}
                 className="relative z-20 rounded-[2.5rem] overflow-hidden shadow-2xl border-4 border-white aspect-[4/5]"
               >
                 <img 
                  src="https://images.unsplash.com/photo-1544027993-37dbfe43562a?q=80&w=2070&auto=format&fit=crop" 
                  alt="Community Support" 
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
               </motion.div>
               <motion.div 
                 initial={{ opacity: 0, x: 20 }}
                 whileInView={{ opacity: 1, x: 0 }}
                 viewport={{ once: true }}
                 transition={{ delay: 0.2 }}
                 className="relative z-10 rounded-[2.5rem] overflow-hidden shadow-2xl border-4 border-white aspect-[4/5] translate-y-12"
               >
                 <img 
                  src="https://images.unsplash.com/photo-1488521787991-ed7bbaae773c?q=80&w=2070&auto=format&fit=crop" 
                  alt="Children at Shelter" 
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
               </motion.div>
               
               {/* Decorative element */}
               <div className="absolute -bottom-10 -right-10 w-40 h-40 bg-primary/10 rounded-full blur-3xl z-0"></div>
               <div className="absolute -top-10 -left-10 w-40 h-40 bg-sage/10 rounded-full blur-3xl z-0"></div>
             </div>
          </div>
        </div>
      </section>
    </div>
  );
};
