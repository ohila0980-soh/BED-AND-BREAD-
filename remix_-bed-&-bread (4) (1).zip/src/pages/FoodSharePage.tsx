import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { UtensilsCrossed, MapPin, Package, Clock, Info, ShieldCheck, ChevronRight } from 'lucide-react';
import { motion } from 'motion/react';
import { useApp } from '../AppContext';
import { POINT_VALUES } from '../constants';

export const FoodSharePage = () => {
  const { addFoodDonation, user } = useApp();
  const navigate = useNavigate();
  const [submitting, setSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!user) {
      navigate('/auth', { state: { from: '/foodshare' } });
      return;
    }

    setSubmitting(true);
    const formData = new FormData(e.target as HTMLFormElement);
    const pointsEarned = POINT_VALUES.GENERAL_FOOD;
    
    try {
      await addFoodDonation({
        restaurantName: formData.get('restaurant') as string,
        location: formData.get('location') as string,
        quantity: formData.get('quantity') as string,
        whatsappNumber: formData.get('whatsapp') as string,
        pointsEarned
      });

      navigate('/foodshare-success', { state: { pointsEarned } });
    } catch (err) {
      console.error("FoodShare Error:", err);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-12">
      <div className="grid lg:grid-cols-2 gap-16 items-center">
        <div>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-orange-50 text-orange-700 rounded-full text-sm font-bold mb-6">
              <UtensilsCrossed className="h-4 w-4" /> B2B Social Impact
            </div>
            <h1 className="text-5xl font-black text-earth mb-6 tracking-tight leading-tight">
              Share Surplus, <br />
              <span className="text-primary">Stop Hunger.</span>
            </h1>
            <p className="text-xl text-slate-600 mb-8 leading-relaxed">
              Are you a restaurant owner, cafe proprietor, or event organizer? Don't let good food go to waste. Use our FoodShare network to connect with local shelters in minutes.
            </p>
            
            <div className="space-y-6 mb-10">
              {[
                { title: 'Tax Benefits', desc: 'Receive tax exemption certificates for your corporate social responsibility.' },
                { title: 'Quick Pickup', desc: 'Our volunteer network handles the logistics of food transport.' },
                { title: 'Community Trust', desc: 'Your brand will be featured in our "Good Business" honors list.' },
              ].map((benefit, i) => (
                <div key={i} className="flex gap-4">
                  <div className="bg-white shadow-md p-2 rounded-xl border border-orange-50 flex-none h-fit">
                    <ShieldCheck className="h-6 w-6 text-primary" />
                  </div>
                  <div>
                    <h4 className="font-bold text-clay-deep">{benefit.title}</h4>
                    <p className="text-slate-500 text-sm leading-relaxed">{benefit.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </motion.div>
        </div>

        <motion.div 
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="bg-white p-10 md:p-12 rounded-[3rem] shadow-2xl border border-orange-50 bg relative overflow-hidden"
        >
          <div className="relative z-10">
            <h3 className="text-2xl font-bold mb-8 flex items-center gap-3 text-clay-deep">
              FoodShare Donation Form
            </h3>
            
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="space-y-2">
                <label className="text-sm font-bold text-earth">Business/Restaurant Name</label>
                <input required name="restaurant" className="w-full px-4 py-4 bg-sand border border-orange-100 rounded-2xl focus:ring-2 focus:ring-primary outline-none" placeholder="e.g. The Green Kitchen" />
              </div>

              <div className="grid md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-sm font-bold text-earth">Location/Street</label>
                  <div className="relative">
                    <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-slate-400" />
                    <input required name="location" className="w-full pl-11 pr-4 py-4 bg-sand border border-orange-100 rounded-2xl outline-none" placeholder="Koramangala" />
                  </div>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-bold text-earth">Quantity (Meals/KG)</label>
                  <div className="relative">
                    <Package className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-slate-400" />
                    <input required name="quantity" className="w-full pl-11 pr-4 py-4 bg-sand border border-orange-100 rounded-2xl outline-none" placeholder="e.g. 50 Meals" />
                  </div>
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-sm font-bold text-earth">WhatsApp Number</label>
                  <div className="relative">
                    <div className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 font-bold">+91</div>
                    <input required name="whatsapp" type="tel" pattern="[0-9]{10}" className="w-full pl-12 pr-4 py-4 bg-sand border border-orange-100 rounded-2xl outline-none" placeholder="9876543210" title="10-digit mobile number" />
                  </div>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-bold text-earth">Preferred Pickup Time</label>
                  <div className="relative">
                    <Clock className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-slate-400" />
                    <input required name="time" type="time" className="w-full pl-11 pr-4 py-4 bg-sand border border-orange-100 rounded-2xl outline-none" />
                  </div>
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-bold text-earth">Additional Notes</label>
                <div className="relative">
                  <Info className="absolute left-3 top-3 h-5 w-5 text-slate-400" />
                  <textarea name="notes" className="w-full pl-11 pr-4 py-4 bg-sand border border-orange-100 rounded-2xl outline-none min-h-[100px]" placeholder="Specific handling instructions or food types..." />
                </div>
              </div>

              <button
                type="submit"
                disabled={submitting}
                className="w-full py-5 bg-primary hover:bg-clay-deep text-white font-bold rounded-2xl shadow-xl hover:shadow-orange-900/10 transition-all flex items-center justify-center gap-3 group disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {submitting ? 'Processing...' : 'Submit Food Donation'}
                {!submitting && <ChevronRight className="h-5 w-5 group-hover:translate-x-1 transition-transform" />}
              </button>
            </form>
          </div>
          <div className="absolute -bottom-10 -right-10 w-40 h-40 bg-orange-50 rounded-full"></div>
        </motion.div>
      </div>
    </div>
  );
};
