import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { CheckCircle, Heart, Star, LayoutDashboard, Home, ArrowRight, Gift, Trophy, Soup } from 'lucide-react';
import { motion } from 'motion/react';
import { useApp } from '../AppContext';

export const DonationSuccessPage = () => {
  const location = useLocation();
  const { user } = useApp();
  const pointsEarned = location.state?.pointsEarned || 0;

  return (
    <div className="min-h-[70vh] flex items-center justify-center p-4">
      <motion.div 
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        className="max-w-2xl w-full bg-white rounded-[3rem] shadow-2xl p-10 md:p-16 text-center border border-orange-50"
      >
        <div className="relative inline-block mb-8">
           <motion.div 
             animate={{ scale: [1, 1.2, 1] }}
             transition={{ duration: 2, repeat: Infinity }}
             className="bg-sage/10 p-8 rounded-full"
           >
            <CheckCircle className="h-16 w-16 text-sage" />
           </motion.div>
           <motion.div 
             initial={{ opacity: 0, rotate: -20 }}
             animate={{ opacity: 1, rotate: 0 }}
             transition={{ delay: 0.5 }}
             className="absolute -top-4 -right-4 bg-primary text-white p-3 rounded-2xl font-black text-xl shadow-lg shadow-orange-900/10"
           >
            +{pointsEarned} PTS
           </motion.div>
        </div>
        
        <h1 className="text-4xl font-black text-clay-deep mb-4 tracking-tight">Donation Successful!</h1>
        <p className="text-xl text-slate-600 mb-10 leading-relaxed">
          Your kindness has just made someone's day brighter. <br />We've recorded your {pointsEarned} points.
        </p>

        <div className="grid grid-cols-2 gap-4 mb-10">
          <div className="bg-sand p-6 rounded-[2rem] border border-orange-100">
            <div className="text-sm font-bold text-slate-500 uppercase mb-1">Impact Level</div>
             <div className="text-2xl font-black text-earth tracking-tight">Kindness Ninja</div>
          </div>
          <div className="bg-sand p-6 rounded-[2rem] border border-orange-100">
             <div className="text-sm font-bold text-slate-500 uppercase mb-1">Total Points</div>
             <div className="text-2xl font-black text-primary tracking-tight">{user?.points || 0}</div>
          </div>
        </div>

        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Link to="/dashboard" className="px-8 py-4 bg-primary text-white font-bold rounded-2xl shadow-lg hover:bg-clay-deep hover:shadow-orange-900/10 transition-all flex items-center justify-center gap-2">
            View Dashboard <LayoutDashboard className="h-5 w-5" />
          </Link>
          <Link to="/" className="px-8 py-4 border-2 border-orange-100 text-earth font-bold rounded-2xl hover:bg-sand transition-all flex items-center justify-center gap-2">
            Return Home <Home className="h-5 w-5" />
          </Link>
        </div>
      </motion.div>
    </div>
  );
};

export const FoodShareSuccessPage = () => {
  const { user } = useApp();
  const location = useLocation();
  const pointsEarned = location.state?.pointsEarned || 0;

  return (
    <div className="min-h-[70vh] flex items-center justify-center p-4">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="max-w-2xl w-full bg-white rounded-[3rem] shadow-2xl p-10 md:p-16 text-center border border-orange-50"
      >
        <div className="bg-orange-50 p-8 rounded-full inline-block mb-8 relative">
           <Soup className="h-16 w-16 text-primary" />
           <motion.div 
              initial={{ opacity: 0, scale: 0 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.5 }}
              className="absolute -top-2 -right-2 bg-primary text-white px-3 py-1 rounded-xl font-bold text-sm shadow-md"
           >
             +{pointsEarned} PTS
           </motion.div>
        </div>
        
        <h1 className="text-4xl font-black text-clay-deep mb-4 tracking-tight">Food Shared Successfully!</h1>
        <p className="text-xl text-slate-600 mb-10 leading-relaxed">
          The FoodShare network is now matching your donation with the nearest shelter. Our volunteers will contact you for pickup shortly.
        </p>

        <div className="bg-earth text-white p-8 rounded-[2rem] mb-10 flex items-center justify-between">
          <div className="text-left">
            <div className="text-clay-light font-bold uppercase text-xs mb-1">Your Contribution</div>
            <div className="text-xl font-bold">Recorded {pointsEarned} Points</div>
          </div>
          <div className="bg-white/10 px-4 py-2 rounded-xl flex items-center gap-2">
             <Trophy className="h-5 w-5 text-clay-light" />
             <span className="font-bold text-sm">{(user?.points || 0)} Total Pts</span>
          </div>
        </div>

        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Link to="/dashboard" className="px-8 py-4 bg-primary text-white font-bold rounded-2xl shadow-lg hover:bg-clay-deep hover:shadow-orange-900/10 transition-all flex items-center justify-center gap-2">
            My Impact <LayoutDashboard className="h-5 w-5" />
          </Link>
          <Link to="/" className="px-8 py-4 border-2 border-orange-100 text-earth font-bold rounded-2xl hover:bg-sand transition-all flex items-center justify-center gap-2">
            Back Home
          </Link>
        </div>
      </motion.div>
    </div>
  );
};
