import React, { useState, useEffect } from 'react';
import { MapContainer, TileLayer, Marker, Popup, useMap } from 'react-leaflet';
import L from 'leaflet';
import { MapPin, Search, Home, Phone, Briefcase, CheckCircle, ArrowRight, ShieldCheck, Navigation as NavIcon, Star, Filter, Heart, Info } from 'lucide-react';
import { BENGALURU_SHELTERS, POINT_VALUES } from '../constants';
import { motion, AnimatePresence } from 'motion/react';
import { useApp } from '../AppContext';
import { cn } from '../lib/utils';
import { Shelter } from '../types';

// Fix for Leaflet default icon paths in React
// @ts-ignore
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png',
  iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
});

// Custom icons based on type
const createCustomIcon = (type: string) => {
  const color = type === 'Orphanage' ? '#F97316' : type === 'Old-Age Home' ? '#22C55E' : '#C05621';
  return L.divIcon({
    html: `<div style="background-color: ${color}; width: 30px; height: 30px; border-radius: 50%; border: 3px solid white; display: flex; align-items: center; justify-content: center; color: white; font-weight: bold; font-size: 10px; box-shadow: 0 4px 6px -1px rgb(0 0 0 / 0.1); transform: translate(-5%, -5%);">S</div>`,
    className: 'custom-div-icon',
    iconSize: [30, 30],
    iconAnchor: [15, 15]
  });
};

// Helper for distance calc (Haversine)
const calculateDistance = (lat1: number, lon1: number, lat2: number, lon2: number) => {
  const R = 6371; // km
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLon = (lon2 - lon1) * Math.PI / 180;
  const a = 
    Math.sin(dLat/2) * Math.sin(dLat/2) +
    Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * 
    Math.sin(dLon/2) * Math.sin(dLon/2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
  return R * c;
};

const ChangeView = ({ center, zoom }: { center: [number, number], zoom: number }) => {
  const map = useMap();
  useEffect(() => {
    map.setView(center, zoom);
  }, [center, zoom, map]);
  return null;
};

export const FindShelterPage = () => {
  const [activeView, setActiveView] = useState<'report' | 'browse'>('browse');
  const [formData, setFormData] = useState({
    location: '',
    name: '',
    ageCategory: 'Adult',
    city: 'Bengaluru',
    info: ''
  });
  
  const [userLocation, setUserLocation] = useState<[number, number]>([12.9716, 77.5946]); // Default Bangalore Center
  const [mapCenter, setMapCenter] = useState<[number, number]>([12.9716, 77.5946]);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedShelterId, setSelectedShelterId] = useState<string | null>(null);
  const [isReporting, setIsReporting] = useState(false);
  const [isGeocoding, setIsGeocoding] = useState(false);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  const { addPoints, addBadge, submitReport, shelters: firestoreShelters } = useApp();
  
  const baseShelters = firestoreShelters.length > 0 ? firestoreShelters : BENGALURU_SHELTERS;

  // Auto-fetch location on mount
  useEffect(() => {
    getUserLocation();
  }, []);

  // Handle selection from list
  const handleShelterClick = (shelter: Shelter) => {
    setSelectedShelterId(shelter.id);
    setMapCenter([shelter.lat, shelter.lng]);
  };

  // Calculate distances and sort
  const sortedShelters = [...baseShelters].map(s => {
    const d = calculateDistance(userLocation[0], userLocation[1], s.lat, s.lng);
    return { ...s, distanceNum: d, distanceInKm: `${d.toFixed(1)} km` };
  }).sort((a, b) => a.distanceNum - b.distanceNum);

  const handleApplyJob = (shelterName: string) => {
    addPoints(POINT_VALUES.APPLY_JOB);
    addBadge('Community Worker', '👷');
    alert(`Applied successfully to ${shelterName}! You've earned ${POINT_VALUES.APPLY_JOB} points.`);
  };

  const handleReportSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsReporting(true);
    try {
      await submitReport(formData.location, formData.info);
      setSuccessMessage(`Report submitted! Redirecting to nearby shelters...`);
      setTimeout(() => {
        setSuccessMessage(null);
        setActiveView('browse');
      }, 2000);
    } catch (err) {
      console.error(err);
    } finally {
      setIsReporting(false);
    }
  };

  const getUserLocation = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition((position) => {
        setUserLocation([position.coords.latitude, position.coords.longitude]);
      });
    }
  };

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchQuery.trim()) return;
    
    setIsGeocoding(true);
    try {
      // Free Nominatim API
      const response = await fetch(`https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(searchQuery + ", Bengaluru")}&limit=1`);
      const data = await response.json();
      if (data && data.length > 0) {
        const result = data[0];
        const isBangalore = result.display_name.toLowerCase().includes('bengaluru') || result.display_name.toLowerCase().includes('bangalore');
        
        if (isBangalore) {
          const lat = parseFloat(result.lat);
          const lon = parseFloat(result.lon);
          setUserLocation([lat, lon]);
          setMapCenter([lat, lon]);
          setSelectedShelterId(null);
        } else {
          alert("Place not found in Bengaluru. This platform is currently exclusive to Bengaluru.");
        }
      } else {
        alert("Location not found. Please try a more specific area in Bengaluru.");
      }
    } catch (error) {
       console.error("Geocoding error:", error);
    } finally {
      setIsGeocoding(false);
    }
  };

  return (
    <div className="min-h-screen bg-sand px-4 pb-20">
      <div className="max-w-7xl mx-auto py-12">
        <header className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6 mb-12">
          <div>
            <h1 className="text-4xl font-black text-earth mb-2 tracking-tighter">Verified Shelter <span className="text-primary">Network</span></h1>
            <p className="text-slate-500 font-medium max-w-xl">Find immediate housing, food, and job opportunities using official OpenStreetMap data. No paid APIs required.</p>
          </div>
          <div className="flex bg-white p-1.5 rounded-2xl shadow-sm border border-orange-50">
            <button 
              onClick={() => setActiveView('browse')}
              className={cn(
                "px-6 py-3 rounded-xl font-black text-xs uppercase tracking-widest transition-all",
                activeView === 'browse' ? "bg-primary text-white shadow-lg" : "text-slate-400 hover:text-earth"
              )}
            >
              Browse Map
            </button>
            <button 
              onClick={() => setActiveView('report')}
              className={cn(
                "px-6 py-3 rounded-xl font-black text-xs uppercase tracking-widest transition-all",
                activeView === 'report' ? "bg-primary text-white shadow-lg" : "text-slate-400 hover:text-earth"
              )}
            >
              Report Case
            </button>
          </div>
        </header>

        {successMessage && (
          <motion.div 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-green-500 text-white px-8 py-4 rounded-2xl mb-8 flex items-center justify-between shadow-lg"
          >
            <div className="flex items-center gap-3">
              <ShieldCheck className="h-6 w-6" />
              <span className="font-bold">{successMessage}</span>
            </div>
          </motion.div>
        )}

        <AnimatePresence mode="wait">
          {activeView === 'browse' ? (
            <motion.div 
              key="browse"
              initial={{ opacity: 0, scale: 0.98 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.98 }}
              className="grid lg:grid-cols-12 gap-8"
            >
              {/* Search and List Side */}
              <div className="lg:col-span-4 flex flex-col gap-6">
                <div className="bg-white p-6 rounded-[2.5rem] shadow-sm border border-orange-50">
                  <form onSubmit={handleSearch} className="relative mb-4">
                    <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-slate-400" />
                    <input 
                      className="w-full pl-12 pr-4 py-4 bg-sand rounded-2xl outline-none font-bold text-earth border border-transparent focus:border-primary transition-all"
                      placeholder="Enter area name in Bangalore..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                    />
                    <button type="submit" hidden></button>
                  </form>
                  <button 
                    onClick={getUserLocation}
                    className="w-full flex items-center justify-center gap-2 py-3 text-primary font-black text-[10px] uppercase tracking-widest border-2 border-orange-100 rounded-2xl hover:bg-orange-50 transition-all"
                  >
                    <NavIcon className="h-4 w-4" /> Use My Location
                  </button>
                  {isGeocoding && <p className="text-[8px] text-primary font-black uppercase tracking-widest mt-2 text-center animate-pulse">Locating on map...</p>}
                </div>

                <div className="bg-white rounded-[2.5rem] p-6 shadow-sm border border-orange-50 flex-grow max-h-[600px] overflow-y-auto scrollbar-hide">
                  <div className="flex justify-between items-center mb-6 px-2">
                     <h3 className="font-black text-earth uppercase text-xs tracking-widest">Sorted by Nearest</h3>
                     <Filter className="h-4 w-4 text-slate-300" />
                  </div>
                  <div className="space-y-4">
                    {sortedShelters.map((shelter) => (
                      <div 
                        key={shelter.id}
                        onClick={() => handleShelterClick(shelter)}
                        className={cn(
                          "p-5 rounded-3xl cursor-pointer transition-all border group",
                          selectedShelterId === shelter.id 
                            ? "bg-earth text-white border-earth" 
                            : "bg-sand border-orange-50 hover:bg-white hover:shadow-md"
                        )}
                      >
                        <div className="flex justify-between items-start mb-3">
                          <span className={cn(
                            "text-[8px] font-black uppercase tracking-widest px-2 py-1 rounded-full",
                            selectedShelterId === shelter.id ? "bg-white/10 text-white" : "bg-orange-100 text-primary"
                          )}>
                            {shelter.type}
                          </span>
                          <span className={cn(
                            "text-[10px] font-bold",
                            selectedShelterId === shelter.id ? "text-orange-200" : "text-green-600"
                          )}>
                            {shelter.beds} Beds Free
                          </span>
                        </div>
                        <h4 className="font-black text-sm mb-1">{shelter.name}</h4>
                        <div className="flex justify-between items-end">
                          <p className={cn(
                            "text-[10px] font-medium opacity-60",
                            selectedShelterId === shelter.id ? "text-white" : "text-slate-500"
                          )}>
                            {shelter.address.split(',')[0]}
                          </p>
                          <span className="text-[10px] font-black uppercase tracking-widest">{shelter.distanceInKm || '0 km'}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Map Side (Leaflet) */}
              <div className="lg:col-span-8 h-[600px] lg:h-[750px] relative">
                <div className="absolute inset-0 rounded-[3rem] overflow-hidden shadow-2xl border-8 border-white z-0">
                  <MapContainer 
                    center={mapCenter} 
                    zoom={13} 
                    style={{ height: '100%', width: '100%' }}
                    scrollWheelZoom={true}
                  >
                    <TileLayer
                      attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
                      url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                    />
                    <ChangeView center={mapCenter} zoom={selectedShelterId ? 15 : 13} />
                    
                    {sortedShelters.map((shelter) => (
                      <Marker 
                        key={shelter.id} 
                        position={[shelter.lat, shelter.lng]}
                        icon={createCustomIcon(shelter.type)}
                        eventHandlers={{
                          click: () => setSelectedShelterId(shelter.id),
                        }}
                      >
                        <Popup>
                          <div className="p-1 min-w-[200px]">
                            <div className="flex justify-between items-center mb-2">
                              <span className="text-[8px] font-black uppercase tracking-widest text-primary">{shelter.type}</span>
                              <span className="text-[9px] font-bold text-green-600">{shelter.beds} Beds</span>
                            </div>
                            <h4 className="font-black text-earth text-sm mb-1">{shelter.name}</h4>
                            <p className="text-[10px] text-slate-500 mb-3">{shelter.address}</p>
                            <button 
                              onClick={() => handleApplyJob(shelter.name)}
                              className="w-full py-2 bg-primary text-white text-[9px] font-black uppercase tracking-widest rounded-lg"
                            >
                              Apply for Job (+40 XP)
                            </button>
                            <a 
                              href={`https://www.google.com/maps/dir/?api=1&destination=${shelter.lat},${shelter.lng}`}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="mt-2 block text-center py-2 border border-orange-100 text-[9px] font-black uppercase tracking-widest rounded-lg text-earth"
                            >
                              Get Directions
                            </a>
                          </div>
                        </Popup>
                      </Marker>
                    ))}
                    
                    {/* User Location Marker */}
                    <Marker position={userLocation}>
                       <Popup>You are here</Popup>
                    </Marker>
                  </MapContainer>
                </div>
              </div>
            </motion.div>
          ) : (
            <motion.div 
              key="report"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 20 }}
              className="grid lg:grid-cols-2 gap-12"
            >
              <div className="bg-white p-10 rounded-[3rem] shadow-xl border border-orange-50">
                <form onSubmit={handleReportSubmit} className="space-y-6">
                  <div className="space-y-2">
                    <label className="text-sm font-black text-earth ml-1 uppercase tracking-widest">Current Location</label>
                    <div className="relative">
                      <MapPin className="absolute left-4 top-4 h-5 w-5 text-slate-400" />
                      <textarea
                        required
                        className="w-full pl-12 pr-4 py-4 bg-sand border border-transparent rounded-2xl focus:border-primary outline-none min-h-[120px] font-bold"
                        placeholder="Where did you see someone in need? Be descriptive..."
                        value={formData.location}
                        onChange={(e) => setFormData({...formData, location: e.target.value})}
                      />
                    </div>
                  </div>
                  <div className="grid md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <label className="text-sm font-black text-earth ml-1 uppercase tracking-widest">Age Group</label>
                      <select 
                        className="w-full px-4 py-4 bg-sand border border-transparent rounded-2xl outline-none font-bold appearance-none"
                        value={formData.ageCategory}
                        onChange={(e) => setFormData({...formData, ageCategory: e.target.value})}
                      >
                        <option>Adult</option>
                        <option>Senior</option>
                        <option>Child</option>
                      </select>
                    </div>
                    <div className="space-y-2">
                      <label className="text-sm font-black text-earth ml-1 uppercase tracking-widest">Contact Info (Optional)</label>
                      <input 
                        type="text"
                        className="w-full px-4 py-4 bg-sand border border-transparent rounded-2xl outline-none font-bold"
                        placeholder="Your phone number"
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-black text-earth ml-1 uppercase tracking-widest">Details of Help Needed</label>
                    <textarea
                      className="w-full px-4 py-4 bg-sand border border-transparent rounded-2xl outline-none font-bold min-h-[100px]"
                      placeholder="Food, medicines, or immediate shelter?"
                      value={formData.info}
                      onChange={(e) => setFormData({...formData, info: e.target.value})}
                    />
                  </div>
                  <button 
                    type="submit"
                    disabled={isReporting}
                    className="w-full py-5 bg-primary hover:bg-earth text-white font-black rounded-2xl shadow-xl transition-all uppercase tracking-widest flex items-center justify-center gap-3"
                  >
                    {isReporting ? 'Submitting Report...' : 'Submit Report (+50 XP)'}
                    {!isReporting && <ArrowRight className="h-5 w-5" />}
                  </button>
                </form>
              </div>

              <div className="space-y-8">
                <div className="bg-earth p-10 rounded-[3rem] text-white shadow-2xl relative overflow-hidden">
                  <div className="relative z-10">
                    <h3 className="text-3xl font-black mb-6 tracking-tight">Report for Good.</h3>
                    <div className="space-y-6">
                      <div className="flex gap-4">
                        <div className="w-10 h-10 bg-white/10 rounded-xl flex items-center justify-center shrink-0">
                          <Star className="h-5 w-5 text-clay-light" />
                        </div>
                        <div>
                          <p className="font-bold mb-1">Instant Response</p>
                          <p className="text-sm text-white/60">Local verified volunteers get notified within 5 minutes of your report.</p>
                        </div>
                      </div>
                      <div className="flex gap-4">
                        <div className="w-10 h-10 bg-white/10 rounded-xl flex items-center justify-center shrink-0">
                          <Heart className="h-5 w-5 text-red-300" />
                        </div>
                        <div>
                          <p className="font-bold mb-1">Impact Verified</p>
                          <p className="text-sm text-white/60">We track every report until shelter or help is successfully provided.</p>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="absolute bottom-0 right-0 w-64 h-64 bg-primary/20 blur-[80px] -mb-32 -mr-32"></div>
                </div>

                <div className="aspect-video rounded-[3rem] overflow-hidden border-8 border-white shadow-lg relative group">
                  <img 
                    src="https://images.unsplash.com/photo-1469571486292-0ba58a3f068b?q=80&w=2070&auto=format&fit=crop" 
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" 
                    alt="Care" 
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-earth/80 to-transparent flex items-end p-8">
                    <p className="text-white font-bold text-lg">"The greatest good is what we do for one another."</p>
                  </div>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
};
