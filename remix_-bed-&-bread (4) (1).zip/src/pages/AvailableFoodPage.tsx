import React, { useState, useEffect } from 'react';
import { Utensils, MapPin, Package, MessageCircle, Clock, Search, ChevronRight } from 'lucide-react';
import { motion } from 'motion/react';
import { collection, query, where, getDocs, orderBy } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { FoodDonation } from '../types';

export const AvailableFoodPage = () => {
  const [listings, setListings] = useState<FoodDonation[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('');

  useEffect(() => {
    const fetchListings = async () => {
      try {
        const q = query(
          collection(db, 'foodDonations'),
          where('status', '==', 'available'),
          orderBy('date', 'desc')
        );
        const querySnapshot = await getDocs(q);
        const data = querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as FoodDonation));
        setListings(data);
      } catch (error) {
        console.error("Error fetching listings:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchListings();
  }, []);

  const filteredListings = listings.filter(l => 
    l.restaurantName.toLowerCase().includes(filter.toLowerCase()) ||
    l.location.toLowerCase().includes(filter.toLowerCase())
  );

  const getWhatsAppLink = (number: string, restaurant: string) => {
    const cleanNumber = number.replace(/\D/g, '');
    const fullNumber = cleanNumber.startsWith('91') ? cleanNumber : `91${cleanNumber}`;
    const message = encodeURIComponent(`Hi, I'm interested in the food listing from "${restaurant}" posted on Bed & Bread. Is it still available?`);
    return `https://wa.me/${fullNumber}?text=${message}`;
  };

  return (
    <div className="min-h-screen bg-sand pb-20">
      <div className="bg-primary text-white py-16 px-4">
        <div className="max-w-7xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <h1 className="text-4xl md:text-5xl font-black mb-4 tracking-tighter">
              Food <span className="text-clay-light">Rescue</span> Network
            </h1>
            <p className="text-lg opacity-90 max-w-2xl">
              Connect directly with businesses offering surplus food. Every meal saved is a step towards zero hunger.
            </p>
          </motion.div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 -mt-8">
        <div className="bg-white p-4 rounded-3xl shadow-xl flex items-center gap-4 mb-12">
          <Search className="h-6 w-6 text-slate-400 ml-2" />
          <input 
            value={filter}
            onChange={(e) => setFilter(e.target.value)}
            className="flex-grow py-2 outline-none text-earth font-medium"
            placeholder="Search by restaurant or location..."
          />
        </div>

        {loading ? (
          <div className="flex justify-center py-20">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
          </div>
        ) : filteredListings.length > 0 ? (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredListings.map((item, index) => (
              <motion.div
                key={item.id}
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: index * 0.05 }}
                className="bg-white rounded-[2.5rem] p-8 shadow-lg border border-orange-50 hover:shadow-xl transition-all group"
              >
                <div className="bg-orange-50 w-14 h-14 rounded-[1.25rem] flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                  <Utensils className="h-7 w-7 text-primary" />
                </div>
                
                <h3 className="text-2xl font-black text-earth mb-2">{item.restaurantName}</h3>
                
                <div className="space-y-3 mb-8">
                  <div className="flex items-center gap-3 text-slate-500 font-medium">
                    <MapPin className="h-4 w-4 text-primary shrink-0" />
                    <span>{item.location}</span>
                  </div>
                  <div className="flex items-center gap-3 text-slate-500 font-medium">
                    <Package className="h-4 w-4 text-primary shrink-0" />
                    <span>{item.quantity}</span>
                  </div>
                  <div className="flex items-center gap-3 text-slate-500 font-medium">
                    <Clock className="h-4 w-4 text-primary shrink-0" />
                    <span>Posted {new Date(item.date).toLocaleDateString()}</span>
                  </div>
                </div>

                <a 
                  href={getWhatsAppLink(item.whatsappNumber, item.restaurantName)}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full py-4 bg-[#25D366] hover:bg-[#128C7E] text-white font-black rounded-2xl flex items-center justify-center gap-3 transition-colors shadow-lg shadow-green-200"
                >
                  <MessageCircle className="h-5 w-5 fill-current" />
                  Connect via WhatsApp
                </a>
              </motion.div>
            ))}
          </div>
        ) : (
          <div className="text-center py-20 bg-white rounded-[3rem] border border-dashed border-orange-200">
            <Utensils className="h-16 w-16 text-orange-200 mx-auto mb-4" />
            <h3 className="text-2xl font-bold text-earth mb-2">No active listings</h3>
            <p className="text-slate-500">Be the first to share surplus food!</p>
          </div>
        )}
      </div>
    </div>
  );
};
