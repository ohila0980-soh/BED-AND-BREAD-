import React from 'react';
import { useApp } from '../AppContext';
import { LayoutDashboard, Heart, UtensilsCrossed, Award, Gift, Clock, History, ArrowRight, User as UserIcon, Star, MapPin, Trash2, CheckCircle, Download, ChevronRight, Trophy, Shield } from 'lucide-react';
import { motion } from 'motion/react';
import { Link } from 'react-router-dom';
import { cn } from '../lib/utils';
import { REWARDS } from '../constants';

export const DashboardPage = () => {
  const { user, loading, updateFoodStatus, updateDonationStatus, deleteFoodListing } = useApp();
  
  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-slate-500 font-bold uppercase text-xs tracking-widest">Loading Impact Data...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-20 text-center">
         <div className="inline-flex p-4 bg-orange-50 rounded-full mb-6">
           <UserIcon className="h-12 w-12 text-primary" />
         </div>
         <h1 className="text-3xl font-bold mb-4">Dashboard Locked</h1>
         <p className="text-slate-500 mb-8 max-w-md mx-auto">Please sign in to view your impact dashboard and track your contributions.</p>
         <Link to="/auth" className="px-8 py-3 bg-primary text-white font-bold rounded-xl">Sign In Now</Link>
      </div>
    );
  }

  const sections = [
    { label: 'Total Points', value: user.points, icon: Star, color: 'text-clay-light', bg: 'bg-orange-50' },
    { label: 'Badges Earned', value: user.badges.length, icon: Award, color: 'text-primary', bg: 'bg-orange-100/30' },
    { label: 'Donations', value: user.donationHistory.length, icon: Gift, color: 'text-clay-deep', bg: 'bg-red-50' },
    { label: 'Reports', value: (user.reportHistory || []).length, icon: History, color: 'text-sage', bg: 'bg-green-50' },
  ];

  const milestones = [
    { label: 'Starter', points: 100, icon: Star },
    { label: 'Advocate', points: 500, icon: Shield },
    { label: 'Hero', points: 1000, icon: Trophy },
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 py-12">
      <header className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6 mb-12">
        <div>
          <h1 className="text-4xl font-black text-slate-900 mb-2 tracking-tighter">Unified Dashboard</h1>
          <p className="text-slate-500">Welcome back, {user.fullName}! Track your impact and rewards here.</p>
        </div>
        <div className="flex flex-wrap gap-4 mt-4 md:mt-0">
          <Link to="/find-shelter" className="px-6 py-3 bg-white border-2 border-primary text-primary font-black rounded-2xl shadow-sm hover:bg-orange-50 transition-all flex items-center gap-2 group">
            <MapPin className="h-4 w-4 group-hover:scale-110 transition-transform" /> Report Someone
          </Link>
          <Link to="/donate" className="px-6 py-3 bg-primary text-white font-black rounded-2xl shadow-xl hover:shadow-orange-900/20 transition-all flex items-center gap-2 group">
            <Gift className="h-4 w-4 group-hover:scale-110 transition-transform" /> Donate Items
          </Link>
        </div>
      </header>

      {/* Quick Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
        {sections.map((stat, i) => (
          <motion.div 
            key={i}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
            className="bg-white p-6 rounded-[32px] border border-slate-200 shadow-sm"
          >
            <div className={cn("p-3 rounded-2xl w-fit mb-4", stat.bg)}>
              <stat.icon className={cn("h-6 w-6", stat.color)} />
            </div>
            <div className="text-4xl font-black text-slate-800 tracking-tighter mb-1">{stat.value}</div>
            <div className="text-[10px] font-black text-slate-400 uppercase tracking-widest leading-none">{stat.label}</div>
          </motion.div>
        ))}
      </div>

      <div className="grid lg:grid-cols-12 gap-8">
        {/* Milestone & Impact Card */}
        <div className="lg:col-span-12">
          <div className="bg-earth rounded-[3rem] p-8 mb-4 text-white relative overflow-hidden shadow-2xl">
            <div className="relative z-10 flex flex-col md:flex-row justify-between items-center gap-8">
              <div>
                <div className="text-clay-light text-sm font-bold uppercase tracking-widest mb-1">Impact Milestones</div>
                <div className="text-6xl font-black">{user.points} <span className="text-2xl opacity-50 font-bold uppercase tracking-widest ml-2">Points</span></div>
                <div className="mt-4 flex items-center gap-2 bg-white/10 px-4 py-2 rounded-full w-fit">
                  <Award className="h-5 w-5 text-clay-light" />
                  <span className="text-sm font-medium">Rank: Community Supporter</span>
                </div>
              </div>
              
              <div className="flex-1 max-w-xl w-full">
                <div className="flex justify-between text-sm mb-2 font-bold uppercase tracking-widest">
                  <span>Next Milestone: {user.points < 500 ? 'Advocate' : 'Hero'}</span>
                  <span className="text-clay-light">{user.points} / {user.points < 500 ? '500' : '1000'}</span>
                </div>
                <div className="h-4 bg-white/10 rounded-full overflow-hidden border border-white/5">
                  <motion.div 
                    initial={{ width: 0 }}
                    animate={{ width: `${Math.min((user.points / (user.points < 500 ? 500 : 1000)) * 100, 100)}%` }}
                    className="h-full bg-primary shadow-[0_0_20px_rgba(192,86,33,0.5)]"
                  ></motion.div>
                </div>
                <div className="mt-4 flex justify-between">
                  {milestones.map(m => (
                    <div key={m.label} className="text-[10px] uppercase font-black text-white/40 tracking-wider">
                      {m.label} ({m.points})
                    </div>
                  ))}
                </div>
              </div>
            </div>
            <div className="absolute top-0 right-0 w-96 h-96 bg-primary/20 blur-[100px] -mr-48 -mt-48"></div>
          </div>
        </div>

        {/* Left Column: Badges & Rewards */}
        <div className="lg:col-span-8 space-y-8">
          {/* Badges */}
          <div className="bg-white rounded-[40px] p-8 border border-orange-50 shadow-sm">
            <h4 className="text-xl font-black text-earth mb-6 flex items-center gap-3">
              <Trophy className="text-clay-light" /> My Badges
            </h4>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {user.badges.map((badge, i) => (
                <motion.div 
                  key={badge.id}
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: i * 0.05 }}
                  className="bg-sand p-4 rounded-[2rem] border border-orange-50 text-center group cursor-help transition-all hover:bg-white hover:shadow-lg"
                >
                  <div className="text-4xl mb-2 transform group-hover:scale-110 transition-transform">{badge.icon}</div>
                  <div className="font-bold text-earth text-xs mb-1 truncate px-1">{badge.name}</div>
                  <div className="text-[8px] text-slate-400 font-bold uppercase tracking-widest">{new Date(badge.date).toLocaleDateString()}</div>
                </motion.div>
              ))}
              <div className="bg-white/50 p-4 rounded-[2rem] border border-dashed border-orange-100 flex items-center justify-center grayscale opacity-30">
                <div className="text-center">
                  <div className="text-2xl mb-1">🔒</div>
                  <div className="text-[8px] font-black uppercase text-slate-400 tracking-wider">Locked</div>
                </div>
              </div>
            </div>
          </div>

          {/* Rewards Grid */}
          <div className="space-y-6">
            <h4 className="text-xl font-black text-earth flex items-center gap-3 ml-2">
              <Gift className="text-primary" /> Available Rewards
            </h4>
            <div className="grid md:grid-cols-2 gap-6">
              {REWARDS.map((reward) => (
                <div key={reward.id} className="bg-white rounded-[3rem] border border-orange-50 shadow-lg overflow-hidden group hover:shadow-xl transition-all">
                  <div className="p-8">
                    <div className="flex justify-between items-start mb-6">
                      <div className="bg-orange-50 p-3 rounded-2xl text-primary">
                        <Gift className="h-6 w-6" />
                      </div>
                      <div className="bg-earth text-white px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest">
                        {reward.points} XP
                      </div>
                    </div>
                    <h3 className="text-xl font-bold text-earth mb-2">{reward.title}</h3>
                    <p className="text-sm text-slate-500 mb-8 leading-relaxed line-clamp-2">
                      {reward.description}
                    </p>
                    <button className={cn(
                      "w-full py-4 rounded-2xl font-black uppercase tracking-widest text-xs flex items-center justify-center gap-2 transition-all shadow-sm",
                      user.points >= reward.points 
                        ? "bg-primary text-white hover:bg-clay-deep shadow-orange-900/10" 
                        : "bg-slate-50 text-slate-300 cursor-not-allowed"
                    )}>
                      {reward.title.includes('Certificate') ? (
                         <>Download Certificate <Download className="h-4 w-4" /></>
                      ) : (
                         <>Redeem Benefit <ChevronRight className="h-4 w-4" /></>
                      )}
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right Column: Recent Impact & Food Listings */}
        <div className="lg:col-span-4 space-y-8">
          <div className="bg-white rounded-[40px] p-8 border border-orange-50 shadow-sm">
            <h4 className="text-xl font-black text-earth mb-6 flex items-center gap-2">
              Impact Feed <span className="h-1.5 w-1.5 rounded-full bg-sage animate-pulse"></span>
            </h4>
            
            <div className="space-y-4">
              {(user.donationHistory.length === 0 && user.foodDonationHistory.length === 0 && (user.reportHistory || []).length === 0) ? (
                <div className="py-12 text-center text-slate-300">
                  <Clock className="h-8 w-8 mx-auto mb-2 opacity-20" />
                  <p className="text-[10px] font-black uppercase tracking-widest">No activities yet</p>
                </div>
              ) : (
                <div className="space-y-4">
                   {[
                    ...(user.reportHistory || []).map(r => ({ ...r, id: r.id || Math.random().toString(), typeKey: 'report' })),
                    ...user.foodDonationHistory.map(f => ({ ...f, typeKey: 'food' })),
                    ...user.donationHistory.map(d => ({ ...d, typeKey: 'donation' }))
                   ].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()).slice(0, 6).map((item: any) => (
                    <div key={item.id} className="flex items-center gap-4 p-3 rounded-2xl hover:bg-sand transition-colors border border-transparent hover:border-orange-50 group">
                      <div className="w-10 h-10 bg-orange-50 rounded-xl flex items-center justify-center text-lg shadow-sm">
                        {item.typeKey === 'report' ? '📢' : item.typeKey === 'food' ? '🥗' : '📦'}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="text-xs font-black text-earth truncate">{item.location || item.restaurantName || item.type}</div>
                        <div className="text-[8px] font-black text-slate-400 uppercase tracking-widest">
                          {new Date(item.date).toLocaleDateString()} • {item.pointsEarned || 20} XP
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Quick Listing Management */}
          <div className="bg-earth rounded-[40px] p-8 text-white shadow-xl">
            <div className="flex justify-between items-center mb-6">
              <h4 className="text-lg font-black tracking-tight">Active Listings</h4>
              <span className="bg-primary px-2 py-0.5 rounded-lg text-[10px] font-black">
                {user.foodDonationHistory.filter(f => f.status === 'available').length + 
                 user.donationHistory.filter(d => d.status === 'available').length}
              </span>
            </div>
            <div className="space-y-4 mb-6">
              {[
                ...user.foodDonationHistory.filter(f => f.status === 'available').map(f => ({ ...f, typeKey: 'food' })),
                ...user.donationHistory.filter(d => d.status === 'available').map(d => ({ ...d, typeKey: 'donation' }))
              ].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()).slice(0, 4).map(item => (
                <div key={item.id} className="bg-white/5 p-4 rounded-2xl border border-white/10">
                   <div className="text-sm font-bold mb-1 truncate">
                    {item.typeKey === 'food' ? (item as any).restaurantName : `(${item.type}) ${item.details}`}
                   </div>
                   <div className="text-[10px] opacity-60 flex items-center gap-2 mb-3 tracking-widest uppercase truncate font-bold">
                     <MapPin className="h-3 w-3" /> {item.location || 'No location given'}
                   </div>
                   <button 
                      onClick={() => 
                        item.typeKey === 'food' 
                          ? updateFoodStatus(item.id, 'picked-up') 
                          : updateDonationStatus(item.id, 'picked-up')
                      }
                      className="w-full py-2 bg-white/10 hover:bg-white/20 text-white font-black text-[10px] uppercase tracking-widest rounded-xl transition-all"
                   >
                     Mark Picked Up
                   </button>
                </div>
              ))}
              {(user.foodDonationHistory.filter(f => f.status === 'available').length === 0 && 
                user.donationHistory.filter(d => d.status === 'available').length === 0) && (
                <p className="text-xs opacity-40 text-center py-4 font-bold uppercase tracking-widest">All listings completed</p>
              )}
            </div>
            <div className="grid grid-cols-2 gap-2">
              <Link to="/foodshare" className="text-center py-4 bg-primary hover:bg-clay-light text-white font-black rounded-2xl text-[10px] uppercase tracking-widest transition-all">
                List Food
              </Link>
              <Link to="/donate" className="text-center py-4 bg-white/10 hover:bg-white/20 text-white font-black rounded-2xl text-[10px] uppercase tracking-widest transition-all border border-white/10">
                List Item
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
