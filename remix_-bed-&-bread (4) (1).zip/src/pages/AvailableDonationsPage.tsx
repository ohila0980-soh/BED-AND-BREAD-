import React, { useState, useEffect } from 'react';
import { Package, MapPin, Gift, MessageCircle, Clock, Search, Filter, Book, Pill, Shirt } from 'lucide-react';
import { motion } from 'motion/react';
import { collection, query, where, getDocs, orderBy } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { Donation } from '../types';
import { cn } from '../lib/utils';

export const AvailableDonationsPage = () => {
  const [listings, setListings] = useState<Donation[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('');
  const [activeCategory, setActiveCategory] = useState<string>('All');

  useEffect(() => {
    const fetchListings = async () => {
      try {
        const q = query(
          collection(db, 'donations'),
          where('status', '==', 'available'),
          orderBy('date', 'desc')
        );
        const querySnapshot = await getDocs(q);
        const data = querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Donation));
        setListings(data);
      } catch (error) {
        console.error("Error fetching listings:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchListings();
  }, []);

  const filteredListings = listings.filter(l => {
    const matchesSearch = l.details.toLowerCase().includes(filter.toLowerCase()) ||
                        (l.location || '').toLowerCase().includes(filter.toLowerCase());
    const matchesCategory = activeCategory === 'All' || l.type === activeCategory;
    return matchesSearch && matchesCategory;
  });

  const getWhatsAppLink = (number?: string, type?: string) => {
    if (!number) return '#';
    const cleanNumber = number.replace(/\D/g, '');
    const fullNumber = cleanNumber.startsWith('91') ? cleanNumber : `91${cleanNumber}`;
    const message = encodeURIComponent(`Hi, I'm interested in the ${type} donation listed on Bed & Bread. Is it still available?`);
    return `https://wa.me/${fullNumber}?text=${message}`;
  };

  const categories = [
    { name: 'All', icon: Gift },
    { name: 'Clothes', icon: Shirt },
    { name: 'Books', icon: Book },
    { name: 'Medicines', icon: Pill },
  ];

  const getIcon = (type: string) => {
    switch (type) {
      case 'Clothes': return Shirt;
      case 'Books': return Book;
      case 'Medicines': return Pill;
      default: return Package;
    }
  };

  return (
    <div className="min-h-screen bg-sand pb-20">
      <div className="bg-earth text-white py-16 px-4">
        <div className="max-w-7xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <h1 className="text-4xl md:text-5xl font-black mb-4 tracking-tighter">
              Item <span className="text-clay-light">Sharing</span> Marketplace
            </h1>
            <p className="text-lg opacity-90 max-w-2xl">
              Browse clothes, books, and medicines available for pickup. Help us bridge the gap between abundance and need.
            </p>
          </motion.div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 -mt-8">
        <div className="flex flex-col lg:flex-row gap-6 mb-12">
          {/* Search */}
          <div className="flex-grow bg-white p-4 rounded-3xl shadow-xl flex items-center gap-4">
            <Search className="h-6 w-6 text-slate-400 ml-2" />
            <input 
              value={filter}
              onChange={(e) => setFilter(e.target.value)}
              className="flex-grow py-2 outline-none text-earth font-medium"
              placeholder="Search items or locations..."
            />
          </div>

          {/* Category Filter */}
          <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-none">
            {categories.map((cat) => (
              <button
                key={cat.name}
                onClick={() => setActiveCategory(cat.name)}
                className={cn(
                  "px-6 py-4 rounded-2xl font-bold text-sm whitespace-nowrap transition-all flex items-center gap-2",
                  activeCategory === cat.name
                    ? "bg-primary text-white shadow-lg"
                    : "bg-white text-slate-500 hover:bg-orange-50"
                )}
              >
                <cat.icon className="h-4 w-4" />
                {cat.name}
              </button>
            ))}
          </div>
        </div>

        {loading ? (
          <div className="flex justify-center py-20">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
          </div>
        ) : filteredListings.length > 0 ? (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredListings.map((item, index) => {
              const Icon = getIcon(item.type);
              return (
                <motion.div
                  key={item.id}
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: index * 0.05 }}
                  className="bg-white rounded-[2.5rem] p-8 shadow-lg border border-orange-50 hover:shadow-xl transition-all group overflow-hidden relative"
                >
                  <div className="absolute top-0 right-0 p-6 opacity-5 group-hover:opacity-10 transition-opacity">
                    <Icon className="h-24 w-24 -mr-8 -mt-8" />
                  </div>

                  <div className="bg-orange-50 w-14 h-14 rounded-[1.25rem] flex items-center justify-center mb-6 group-hover:scale-110 transition-transform relative z-10">
                    <Icon className="h-7 w-7 text-primary" />
                  </div>
                  
                  <div className="mb-2">
                    <span className="text-[10px] font-black uppercase tracking-widest text-primary bg-orange-50 px-3 py-1 rounded-full">
                      {item.type}
                    </span>
                  </div>
                  <h3 className="text-2xl font-black text-earth mb-4">{item.details}</h3>
                  
                  <div className="space-y-3 mb-8 relative z-10">
                    <div className="flex items-center gap-3 text-slate-500 font-medium">
                      <MapPin className="h-4 w-4 text-primary shrink-0" />
                      <span className="truncate">{item.location || 'Location provided on contact'}</span>
                    </div>
                    <div className="flex items-center gap-3 text-slate-500 font-medium">
                      <Clock className="h-4 w-4 text-primary shrink-0" />
                      <span>Posted {new Date(item.date).toLocaleDateString()}</span>
                    </div>
                  </div>

                  <a 
                    href={getWhatsAppLink(item.whatsappNumber, item.type)}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-full py-4 bg-primary hover:bg-clay-deep text-white font-black rounded-2xl flex items-center justify-center gap-3 transition-colors shadow-lg shadow-orange-900/10 relative z-10"
                  >
                    <MessageCircle className="h-5 w-5" />
                    Request Item
                  </a>
                </motion.div>
              );
            })}
          </div>
        ) : (
          <div className="text-center py-20 bg-white rounded-[3rem] border border-dashed border-orange-200">
            <Gift className="h-16 w-16 text-orange-200 mx-auto mb-4" />
            <h3 className="text-2xl font-bold text-earth mb-2">No items listed</h3>
            <p className="text-slate-500">Check back later or change your filters.</p>
          </div>
        )}
      </div>
    </div>
  );
};
