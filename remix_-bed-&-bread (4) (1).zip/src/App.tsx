import React from 'react';
import { BrowserRouter, Routes, Route, useLocation } from 'react-router-dom';
import { AppProvider } from './AppContext';
import { Navbar, Footer } from './components/Navigation';
import { Chatbot } from './components/Chatbot';
import { LandingPage } from './pages/LandingPage';
import { AuthPage } from './pages/AuthPage';
import { FindShelterPage } from './pages/FindShelterPage';
import { DonationPage } from './pages/DonationPage';
import { DashboardPage } from './pages/DashboardPage';
import { FoodSharePage } from './pages/FoodSharePage';
import { DonationSuccessPage, FoodShareSuccessPage } from './pages/SuccessPages';
import { AvailableFoodPage } from './pages/AvailableFoodPage';
import { AvailableDonationsPage } from './pages/AvailableDonationsPage';

const ScrollToTop = () => {
  const { pathname } = useLocation();
  React.useEffect(() => {
    window.scrollTo(0, 0);
  }, [pathname]);
  return null;
};

export default function App() {
  return (
    <AppProvider>
      <BrowserRouter>
        <ScrollToTop />
        <div className="min-h-screen flex flex-col bg-[#FBF7F0] font-sans">
          <Navbar />
          <main className="flex-grow">
            <Routes>
              <Route path="/" element={<LandingPage />} />
              <Route path="/auth" element={<AuthPage />} />
              <Route path="/find-shelter" element={<FindShelterPage />} />
              <Route path="/donate" element={<DonationPage />} />
              <Route path="/foodshare" element={<FoodSharePage />} />
              <Route path="/dashboard" element={<DashboardPage />} />
              <Route path="/available-food" element={<AvailableFoodPage />} />
              <Route path="/available-donations" element={<AvailableDonationsPage />} />
              <Route path="/donation-success" element={<DonationSuccessPage />} />
              <Route path="/foodshare-success" element={<FoodShareSuccessPage />} />
            </Routes>
          </main>
          <Footer />
          <Chatbot />
        </div>
      </BrowserRouter>
    </AppProvider>
  );
}
