import React, { createContext, useContext, useState, useEffect } from 'react';
import { User, Donation, FoodDonation, Badge, Report, Shelter } from './types';
import { auth, db, logOut, signInWithGoogle, handleFirestoreError, OperationType } from './lib/firebase';
import { 
  onAuthStateChanged, 
  signInWithEmailAndPassword, 
  createUserWithEmailAndPassword,
  updateProfile
} from 'firebase/auth';
import { 
  doc, 
  getDoc, 
  setDoc, 
  updateDoc, 
  collection, 
  query, 
  where, 
  getDocs, 
  addDoc,
  serverTimestamp,
  orderBy,
  limit
} from 'firebase/firestore';

interface AppContextType {
  user: User | null;
  loading: boolean;
  shelters: Shelter[];
  login: (email: string, password: string) => Promise<void>;
  signup: (name: string, age: string, email: string, password: string) => Promise<void>;
  loginWithGoogle: () => Promise<void>;
  logout: () => Promise<void>;
  addPoints: (amount: number) => Promise<void>;
  addDonation: (donation: Omit<Donation, 'id' | 'date'>) => Promise<void>;
  addFoodDonation: (donation: Omit<FoodDonation, 'id' | 'date'>) => Promise<void>;
  addBadge: (name: string, icon: string) => Promise<void>;
  submitReport: (location: string, description: string) => Promise<void>;
  fetchShelters: () => Promise<void>;
  updateFoodStatus: (id: string, status: 'available' | 'picked-up') => Promise<void>;
  updateDonationStatus: (id: string, status: 'available' | 'picked-up' | 'completed') => Promise<void>;
  deleteFoodListing: (id: string) => Promise<void>;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [shelters, setShelters] = useState<Shelter[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchShelters = async () => {
    try {
      const querySnapshot = await getDocs(collection(db, 'shelters'));
      const shelterList = querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Shelter));
      setShelters(shelterList);
    } catch (error) {
      console.error("Error fetching shelters:", error);
    }
  };

  const fetchUserData = async (firebaseUser: { uid: string, displayName?: string | null, email?: string | null }) => {
    try {
      const userRef = doc(db, 'users', firebaseUser.uid);
      const userDoc = await getDoc(userRef);
      
      if (userDoc.exists()) {
        const userData = userDoc.data() as User;
        
        // Fetch history
        const [donations, foodDonations, reports] = await Promise.all([
          getDocs(query(collection(db, 'donations'), where('userId', '==', firebaseUser.uid), orderBy('date', 'desc'), limit(10))).catch(() => ({ docs: [] })),
          getDocs(query(collection(db, 'foodDonations'), where('userId', '==', firebaseUser.uid), orderBy('date', 'desc'), limit(10))).catch(() => ({ docs: [] })),
          getDocs(query(collection(db, 'reports'), where('userId', '==', firebaseUser.uid), orderBy('date', 'desc'), limit(10))).catch(() => ({ docs: [] }))
        ]);

        const updatedUser = {
          ...userData,
          donationHistory: donations.docs.map(d => ({ id: d.id, ...d.data() } as Donation)),
          foodDonationHistory: foodDonations.docs.map(d => ({ id: d.id, ...d.data() } as FoodDonation)),
          reportHistory: reports.docs.map(d => ({ id: d.id, ...d.data() } as Report))
        };
        setUser(updatedUser);
        return updatedUser;
      } else {
        // New user
        const newUser: User = {
          fullName: firebaseUser.displayName || 'User',
          age: 'Unknown',
          email: firebaseUser.email || '',
          points: 50,
          badges: [{ id: 'starter', name: 'New Member', icon: '👤', date: new Date().toISOString() }],
          donationHistory: [],
          foodDonationHistory: [],
          reportHistory: []
        };
        await setDoc(userRef, {
          ...newUser,
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp()
        });
        setUser(newUser);
        return newUser;
      }
    } catch (error) {
      console.error("Error fetching/creating user data:", error);
      setUser(null);
      return null;
    }
  };

  useEffect(() => {
    fetchShelters();
    const unsubscribe = onAuthStateChanged(auth, async (firebaseUser) => {
      if (firebaseUser) {
        await fetchUserData(firebaseUser);
      } else {
        setUser(null);
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const login = async (email: string, password: string) => {
    setLoading(true);
    try {
      const { user: firebaseUser } = await signInWithEmailAndPassword(auth, email, password);
      await fetchUserData(firebaseUser);
    } catch (error) {
      console.error("Login Error:", error);
      throw error;
    } finally {
      setLoading(false);
    }
  };

  const loginWithGoogle = async () => {
    setLoading(true);
    try {
      const firebaseUser = await signInWithGoogle();
      if (firebaseUser) {
        await fetchUserData(firebaseUser);
      }
    } catch (error) {
      console.error("Google Login Error:", error);
      throw error;
    } finally {
      setLoading(false);
    }
  };

  const signup = async (name: string, age: string, email: string, password: string) => {
    setLoading(true);
    try {
      const { user: firebaseUser } = await createUserWithEmailAndPassword(auth, email, password);
      await updateProfile(firebaseUser, { displayName: name });
      
      const newUser: User = {
        fullName: name,
        age: age,
        email: email,
        points: 50,
        badges: [{ id: 'starter', name: 'New Member', icon: '👤', date: new Date().toISOString() }],
        donationHistory: [],
        foodDonationHistory: [],
        reportHistory: []
      };
      
      await setDoc(doc(db, 'users', firebaseUser.uid), {
        ...newUser,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp()
      });
      setUser(newUser);
    } catch (error) {
      console.error("Signup Error:", error);
      throw error;
    } finally {
      setLoading(false);
    }
  };

  const logout = async () => {
    setLoading(true);
    try {
      await logOut();
    } finally {
      setLoading(false);
    }
  };

  const addPoints = async (amount: number) => {
    if (!auth.currentUser || !user) return;
    try {
      const userRef = doc(db, 'users', auth.currentUser.uid);
      await updateDoc(userRef, {
        points: user.points + amount,
        updatedAt: serverTimestamp()
      });
      setUser(prev => prev ? { ...prev, points: prev.points + amount } : null);
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `users/${auth.currentUser.uid}`);
    }
  };

  const addDonation = async (d: Omit<Donation, 'id' | 'date' | 'userId' | 'status'>) => {
    if (!auth.currentUser || !user) return;
    try {
      const status = d.type === 'Funds' ? 'completed' : 'available';
      const docRef = await addDoc(collection(db, 'donations'), {
        ...d,
        userId: auth.currentUser.uid,
        status,
        date: new Date().toISOString()
      });

      const userRef = doc(db, 'users', auth.currentUser.uid);
      const newPoints = user.points + d.pointsEarned;
      await updateDoc(userRef, {
        points: newPoints,
        updatedAt: serverTimestamp()
      });

      const newDonation: Donation = {
        ...d,
        id: docRef.id,
        userId: auth.currentUser.uid,
        status,
        date: new Date().toISOString()
      };

      setUser(prev => prev ? {
        ...prev,
        points: newPoints,
        donationHistory: [newDonation, ...(prev.donationHistory || [])]
      } : null);
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, 'donations');
    }
  };

  const updateDonationStatus = async (id: string, status: 'available' | 'picked-up' | 'completed') => {
    if (!auth.currentUser) return;
    try {
      const donationRef = doc(db, 'donations', id);
      await updateDoc(donationRef, { status });
      
      setUser(prev => prev ? {
        ...prev,
        donationHistory: prev.donationHistory.map(d => d.id === id ? { ...d, status } : d)
      } : null);
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `donations/${id}`);
    }
  };

  const addFoodDonation = async (d: Omit<FoodDonation, 'id' | 'date' | 'userId' | 'status'>) => {
    if (!auth.currentUser || !user) return;
    try {
      const docRef = await addDoc(collection(db, 'foodDonations'), {
        ...d,
        userId: auth.currentUser.uid,
        status: 'available',
        date: new Date().toISOString()
      });

      const userRef = doc(db, 'users', auth.currentUser.uid);
      const newPoints = user.points + d.pointsEarned;
      await updateDoc(userRef, {
        points: newPoints,
        updatedAt: serverTimestamp()
      });

      const newFood: FoodDonation = {
        ...d,
        id: docRef.id,
        userId: auth.currentUser.uid,
        status: 'available',
        date: new Date().toISOString()
      };

      setUser(prev => prev ? {
        ...prev,
        points: newPoints,
        foodDonationHistory: [newFood, ...(prev.foodDonationHistory || [])]
      } : null);
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, 'foodDonations');
    }
  };

  const updateFoodStatus = async (id: string, status: 'available' | 'picked-up') => {
    if (!auth.currentUser) return;
    try {
      const foodRef = doc(db, 'foodDonations', id);
      await updateDoc(foodRef, { status });
      
      setUser(prev => prev ? {
        ...prev,
        foodDonationHistory: prev.foodDonationHistory.map(f => f.id === id ? { ...f, status } : f)
      } : null);
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `foodDonations/${id}`);
    }
  };

  const deleteFoodListing = async (id: string) => {
    if (!auth.currentUser) return;
    try {
      const { deleteDoc } = await import('firebase/firestore');
      await deleteDoc(doc(db, 'foodDonations', id));
      
      setUser(prev => prev ? {
        ...prev,
        foodDonationHistory: prev.foodDonationHistory.filter(f => f.id !== id)
      } : null);
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, `foodDonations/${id}`);
    }
  };

  const addBadge = async (name: string, icon: string) => {
    if (!auth.currentUser || !user) return;
    if (user.badges.find(b => b.name === name)) return;

    const newBadge: Badge = {
      id: Math.random().toString(36).substring(2, 11),
      name,
      icon,
      date: new Date().toISOString()
    };

    try {
      const userRef = doc(db, 'users', auth.currentUser.uid);
      const updatedBadges = [...user.badges, newBadge];
      await updateDoc(userRef, {
        badges: updatedBadges,
        updatedAt: serverTimestamp()
      });

      setUser(prev => prev ? {
        ...prev,
        badges: updatedBadges
      } : null);
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `users/${auth.currentUser.uid}`);
    }
  };

  const submitReport = async (location: string, description: string) => {
    if (!auth.currentUser || !user) return;
    try {
      const docRef = await addDoc(collection(db, 'reports'), {
        userId: auth.currentUser.uid,
        location,
        description,
        status: 'pending',
        date: new Date().toISOString()
      });

      const userRef = doc(db, 'users', auth.currentUser.uid);
      const newPoints = user.points + 50;
      await updateDoc(userRef, {
        points: newPoints,
        updatedAt: serverTimestamp()
      });

      const newReport: Report = {
        id: docRef.id,
        userId: auth.currentUser.uid,
        location,
        description,
        status: 'pending',
        date: new Date().toISOString()
      };

      setUser(prev => prev ? {
        ...prev,
        points: newPoints,
        reportHistory: [newReport, ...(prev.reportHistory || [])]
      } : null);
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, 'reports');
    }
  };

  return (
    <AppContext.Provider value={{ 
      user, 
      loading, 
      shelters,
      login, 
      signup, 
      loginWithGoogle,
      logout, 
      addPoints, 
      addDonation, 
      addFoodDonation, 
      addBadge,
      submitReport,
      fetchShelters,
      updateFoodStatus,
      updateDonationStatus,
      deleteFoodListing
    }}>
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) throw new Error('useApp must be used within AppProvider');
  return context;
};


