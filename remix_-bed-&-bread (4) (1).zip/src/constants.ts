import { Shelter, Reward } from './types';

export const BENGALURU_SHELTERS: Shelter[] = [
  {
    id: '1',
    name: "Shanti Niketan Orphanage",
    type: 'Orphanage',
    beds: 12,
    contact: "+91 80 2345 6789",
    address: "Indiranagar, 10th Main, Bengaluru",
    needs: ["School kits", "Rice", "Bedding"],
    distance: "1.2 km",
    jobOpenings: 2,
    lat: 12.9719,
    lng: 77.6412
  },
  {
    id: '2',
    name: "Jeevan Jyoti Old-Age Home",
    type: 'Old-Age Home',
    beds: 5,
    contact: "+91 80 8765 4321",
    address: "Jayanagar 4th Block, Bengaluru",
    needs: ["Medicines", "Walking sticks", "Volunteers"],
    distance: "4.5 km",
    jobOpenings: 1,
    lat: 12.9250,
    lng: 77.5897
  },
  {
    id: '3',
    name: "Hope Children's Home",
    type: 'Child Shelter',
    beds: 20,
    contact: "+91 80 5555 1111",
    address: "Koramangala 3rd Block, Bengaluru",
    needs: ["Toys", "Baby food", "Milk powder"],
    distance: "2.8 km",
    jobOpenings: 3,
    lat: 12.9352,
    lng: 77.6245
  },
  {
    id: '4',
    name: "Silver Jubilee Senior Care",
    type: 'Old-Age Home',
    beds: 8,
    contact: "+91 99000 12345",
    address: "Whitefield Road, Bengaluru",
    needs: ["Sanitary pads", "Wheelchairs", "Reading books"],
    distance: "12 km",
    jobOpenings: 2,
    lat: 12.9698,
    lng: 77.7499
  }
];

export const REWARDS: Reward[] = [
  { id: '1', title: 'Community Hero Badge', points: 500, description: 'Awarded for exceptional service to the community.' },
  { id: '2', title: '50% Discount - Cafe Coffee Day', points: 200, description: 'Enjoy a treat for your kindness.' },
  { id: '3', title: 'Free Book Set', points: 150, description: 'A collection of inspiring stories.' },
  { id: '4', title: 'Certificate of Excellence', points: 1000, description: 'Official recognition from Bed & Bread India.' }
];

export const POINT_VALUES = {
  REPORT_HOMELESS: 50,
  SHELTER_PLACEMENT: 100,
  DONATE_CLOTHES: 12,
  DONATE_FOOD: 10,
  DONATE_FUNDS: 15,
  GENERAL_FOOD: 20,
  APPLY_JOB: 40
};
