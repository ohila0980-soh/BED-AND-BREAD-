export interface User {
  fullName: string;
  age: string;
  email: string;
  points: number;
  badges: Badge[];
  donationHistory: Donation[];
  foodDonationHistory: FoodDonation[];
  reportHistory?: Report[];
  createdAt?: any;
  updatedAt?: any;
}

export interface Badge {
  id: string;
  name: string;
  icon: string;
  date: string;
}

export interface Donation {
  id: string;
  userId: string;
  type: 'Clothes' | 'Food' | 'Books' | 'Medicines' | 'Funds';
  amount?: string;
  details: string;
  location?: string;
  whatsappNumber?: string;
  status: 'available' | 'picked-up' | 'completed';
  pointsEarned: number;
  date: string;
}

export interface FoodDonation {
  id: string;
  userId: string;
  restaurantName: string;
  location: string;
  quantity: string;
  whatsappNumber: string;
  status: 'available' | 'picked-up';
  pointsEarned: number;
  date: string;
}

export interface Shelter {
  id: string;
  name: string;
  type: 'Orphanage' | 'Old-Age Home' | 'Child Shelter' | 'General';
  beds: number;
  contact: string;
  address: string;
  needs: string[];
  distance: string;
  jobOpenings: number;
  lat: number;
  lng: number;
}

export interface Reward {
  id: string;
  title: string;
  points: number;
  description: string;
}

export interface Report {
  id: string;
  userId: string;
  location: string;
  description: string;
  status: 'pending' | 'verified' | 'resolved';
  date: string;
}
