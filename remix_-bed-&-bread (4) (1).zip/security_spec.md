# Security Spec for Bed & Bread

## Data Invariants
1. A user profile MUST be the same ID as their Auth UID.
2. Users can only modify their own profiles.
3. Users can only read their own donation and food donation histories.
4. Users can only read their own reports.
5. Shelters are read-only for general users.
6. points and badges are protected fields; users can increment points but not freely set them to arbitrary values (actually, the app logic increments them, but we should guard against massive jumps).

## The Dirty Dozen Payloads

1. **Identity Spoofing**: Attempt to create a user profile with a different UID.
2. **Identity Spoofing 2**: Attempt to read another user's profile.
3. **Identity Spoofing 3**: Attempt to update another user's profile points.
4. **Identity Spoofing 4**: Attempt to read another user's donation history.
5. **PII Leak**: Attempt to list all users and their emails.
6. **Orphaned Write**: Create a donation with a non-existent userId.
7. **Resource Poisoning**: Create a shelter with a 1MB address string.
8. **State Shortcutting**: Update a report status from 'pending' to 'resolved' (should be admin only).
9. **Shadow Field**: Adding `isAdmin: true` to a user profile update.
10. **Terminal State Lockdown**: Trying to change a resolved report's description.
11. **Negative Points**: Trying to update points to a negative value.
12. **Mass Badge Assignment**: Trying to update badges with an array of 100 badges.

## Test Runner (Logic verified in rules)

The following `firestore.rules` will be designed to reject all of the above.
